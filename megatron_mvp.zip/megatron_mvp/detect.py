"""模型自动检测与结构规格提取。"""

from __future__ import annotations

import json
from pathlib import Path

from megatron_mvp.types import ModelArtifacts
from megatron_mvp.types import ModelSpec


_WEIGHT_GLOBS = (
    "pytorch_model.bin",
    "pytorch_model-*.bin",
    "model.safetensors",
    "model-*.safetensors",
    "*.safetensors",
)

_TOKENIZER_NAMES = (
    "tokenizer.model",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
)


def _iter_candidate_dirs(root: Path) -> list[Path]:
    """枚举可能的模型目录。

    这里优先看根目录本身，再做一层和两层子目录扫描，避免误扫整个大仓库。
    """
    candidates = [root]
    candidates.extend(path for path in root.iterdir() if path.is_dir())
    for child in root.iterdir():
        if child.is_dir():
            candidates.extend(path for path in child.iterdir() if path.is_dir())
    return candidates


def _collect_weight_files(model_dir: Path) -> tuple[list[Path], str]:
    """收集模型权重文件并推断权重格式。"""
    matched_files: list[Path] = []
    for pattern in _WEIGHT_GLOBS:
        matched_files.extend(sorted(model_dir.glob(pattern)))

    unique_files = sorted({path.resolve() for path in matched_files})
    if not unique_files:
        return [], "unknown"

    suffixes = {path.suffix for path in unique_files}
    if ".safetensors" in suffixes:
        return unique_files, "safetensors"
    return unique_files, "bin"


def detect_hf_model(search_root: Path) -> ModelArtifacts:
    """自动检测 Hugging Face 模型目录。"""
    best_match: ModelArtifacts | None = None

    for candidate_dir in _iter_candidate_dirs(search_root):
        config_path = candidate_dir / "config.json"
        if not config_path.is_file():
            continue

        weight_files, weight_format = _collect_weight_files(candidate_dir)
        if not weight_files:
            continue

        tokenizer_files = [
            path.resolve()
            for name in _TOKENIZER_NAMES
            for path in [candidate_dir / name]
            if path.is_file()
        ]

        artifacts = ModelArtifacts(
            model_dir=candidate_dir.resolve(),
            config_path=config_path.resolve(),
            weight_files=weight_files,
            tokenizer_files=tokenizer_files,
            shard_count=len(weight_files),
            weight_format=weight_format,
        )

        # 优先选择更浅的目录，避免把 tokenizer 等子目录误判成主模型目录。
        if best_match is None or len(artifacts.model_dir.parts) < len(best_match.model_dir.parts):
            best_match = artifacts

    if best_match is None:
        raise FileNotFoundError(
            f"在 {search_root} 下未检测到 Hugging Face 模型目录，需要同时存在 config.json 和权重文件。"
        )

    return best_match


def _estimate_transformer_block_params(
    hidden_size: int,
    intermediate_size: int,
    num_heads: int,
    num_kv_heads: int,
) -> int:
    """按 LLaMA 风格结构做 block-level 参数量粗估。

    第一版只需要粗搜索，因此这里不追求逐张量精确值，只要求数量级稳定。
    """
    kv_hidden_size = hidden_size * num_kv_heads // num_heads
    attention_params = (
        hidden_size * hidden_size
        + hidden_size * kv_hidden_size
        + hidden_size * kv_hidden_size
        + hidden_size * hidden_size
    )
    mlp_params = hidden_size * intermediate_size * 3
    norm_params = hidden_size * 2
    return attention_params + mlp_params + norm_params


def load_model_spec(artifacts: ModelArtifacts) -> ModelSpec:
    """从 Hugging Face config 中提取模型规格。"""
    config = json.loads(artifacts.config_path.read_text(encoding="utf-8"))

    model_type = str(config.get("model_type", "unknown"))
    architecture = str(config.get("architectures", ["unknown"])[0])
    hidden_size = int(config["hidden_size"])
    intermediate_size = int(config["intermediate_size"])
    num_layers = int(config["num_hidden_layers"])
    num_heads = int(config["num_attention_heads"])
    num_kv_heads = int(config.get("num_key_value_heads", num_heads))
    vocab_size = int(config["vocab_size"])
    max_seq_len = int(
        config.get("max_position_embeddings")
        or config.get("max_sequence_length")
        or 2048
    )
    rope_theta = float(config.get("rope_theta", 10000.0))
    rms_norm_eps = float(config.get("rms_norm_eps", 1.0e-6))
    tie_word_embeddings = bool(config.get("tie_word_embeddings", False))
    source_torch_dtype = str(config.get("torch_dtype", "unknown"))

    params_per_layer = _estimate_transformer_block_params(
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
        num_heads=num_heads,
        num_kv_heads=num_kv_heads,
    )
    embedding_params = vocab_size * hidden_size
    lm_head_params = 0 if tie_word_embeddings else vocab_size * hidden_size
    final_norm_params = hidden_size
    estimated_total_params = params_per_layer * num_layers + embedding_params + lm_head_params + final_norm_params

    return ModelSpec(
        model_dir=artifacts.model_dir,
        model_type=model_type,
        architecture=architecture,
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
        num_layers=num_layers,
        num_heads=num_heads,
        num_kv_heads=num_kv_heads,
        vocab_size=vocab_size,
        max_seq_len=max_seq_len,
        rope_theta=rope_theta,
        rms_norm_eps=rms_norm_eps,
        tie_word_embeddings=tie_word_embeddings,
        source_torch_dtype=source_torch_dtype,
        estimated_total_params=estimated_total_params,
        estimated_params_per_layer=params_per_layer,
    )

