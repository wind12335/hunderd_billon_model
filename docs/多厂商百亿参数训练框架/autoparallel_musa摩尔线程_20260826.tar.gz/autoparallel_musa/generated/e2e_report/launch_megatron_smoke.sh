#!/usr/bin/env bash
set -euo pipefail

# 该脚本由 autoparallel 声明式前端生成，并下放到现有 Megatron 执行。
# 脚本角色: smoke_test
# 搜索策略: BLOCK_LEVEL_FAST / BALANCED
# 搜索耗时: 0.0012 秒
# 规划推荐: TP=2, DP=1, WORLD_SIZE=2
# 显式策略: attention=head_shard, mlp=colrow_shard, embedding=vocab_shard, lm_head=vocab_shard
# 三段式策略: attn=(head_shard,head_shard,head_shard), mlp=(colrow_shard,colrow_shard,colrow_shard)
# 当前执行: 当前 smoke test 卡数已覆盖规划 WORLD_SIZE，直接复用规划并行配置，并默认关闭 checkpoint 保存。

ROOT_DIR="/ws/musa_framework"
cd "${ROOT_DIR}"

source "${ROOT_DIR}/scripts/activate_megatron_musa.sh"

export AUTOPARALLEL_ROLE="smoke_test"
export CUDA_DEVICE_MAX_CONNECTIONS="${CUDA_DEVICE_MAX_CONNECTIONS:-1}"
export TORCH_COMPILE_DISABLE="${TORCH_COMPILE_DISABLE:-1}"
export TORCHDYNAMO_DISABLE="${TORCHDYNAMO_DISABLE:-1}"
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export MASTER_PORT="${MASTER_PORT:-29500}"
export NNODES="${NNODES:-1}"
export NODE_RANK="${NODE_RANK:-0}"
export GPUS_PER_NODE="${GPUS_PER_NODE:-2}"
export WORLD_SIZE="$((NNODES * GPUS_PER_NODE))"

export CHECKPOINT_DIR="${CHECKPOINT_DIR:-${ROOT_DIR}/generated/autoparallel/checkpoints}"
export TENSORBOARD_DIR="${TENSORBOARD_DIR:-${ROOT_DIR}/generated/autoparallel/tensorboard}"
export DATA_CACHE_PATH="${DATA_CACHE_PATH:-/ws/musa_framework/generated/e2e_report/data_cache}"
mkdir -p "${CHECKPOINT_DIR}" "${TENSORBOARD_DIR}" "${DATA_CACHE_PATH}"

DATA_ARGS=(
    --mock-data
    --tokenizer-type NullTokenizer
    --vocab-size 32000
)

python3 -m torch.distributed.run     --nproc_per_node "${GPUS_PER_NODE}"     --nnodes "${NNODES}"     --node_rank "${NODE_RANK}"     --master_addr "${MASTER_ADDR}"     --master_port "${MASTER_PORT}"     "${ROOT_DIR}/tools/run_megatron_musa.py" Megatron-LM/pretrain_gpt.py     --rank "${RANK:-0}"     --world-size "${WORLD_SIZE}"     --dist-url "tcp://${MASTER_ADDR}:${MASTER_PORT}"     --use-mcore-models \
    --transformer-impl local \
    --num-layers 2 \
    --hidden-size 64 \
    --ffn-hidden-size 176 \
    --num-attention-heads 8 \
    --seq-length 16 \
    --max-position-embeddings 4096 \
    --position-embedding-type rope \
    --normalization RMSNorm \
    --swiglu \
    --untie-embeddings-and-output-weights \
    --disable-bias-linear \
    --rotary-base 10000 \
    --tensor-model-parallel-size 2 \
    --pipeline-model-parallel-size 1 \
    --micro-batch-size 1 \
    --global-batch-size 1 \
    --bf16 \
    --use-distributed-optimizer \
    --recompute-granularity full \
    --recompute-method uniform \
    --recompute-num-layers 1 \
    --train-iters 3 \
    --lr 0.0001 \
    --min-lr 1e-05 \
    --lr-decay-style cosine \
    --weight-decay 0.1 \
    --clip-grad 1.0 \
    --adam-beta1 0.9 \
    --adam-beta2 0.95 \
    --attention-dropout 0.0 \
    --hidden-dropout 0.0 \
    --init-method-std 0.02 \
    --tensorboard-dir ${TENSORBOARD_DIR} \
    --log-interval 1 \
    --eval-interval 1 \
    --eval-iters 0 \
    --save-interval 1000 \
    "${DATA_ARGS[@]}"
