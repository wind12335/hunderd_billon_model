#!/usr/bin/env bash
set -euo pipefail

# 该脚本由 Megatron 自动并行 MVP 生成。
# 当前推荐模式: current_feasible
# 搜索策略: BLOCK_LEVEL_FAST / BALANCED
# 推荐并行: TP=2, DP=1, WORLD_SIZE=2
# 显式策略: attention=head_shard, mlp=colrow_shard, embedding=vocab_shard, lm_head=vocab_shard
# 三段式策略: attn=(head_shard,head_shard,head_shard), mlp=(colrow_shard,colrow_shard,colrow_shard)

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

source "${ROOT_DIR}/scripts/activate_megatron_musa.sh"

export CUDA_DEVICE_MAX_CONNECTIONS="${CUDA_DEVICE_MAX_CONNECTIONS:-1}"
export TORCH_COMPILE_DISABLE="${TORCH_COMPILE_DISABLE:-1}"
export TORCHDYNAMO_DISABLE="${TORCHDYNAMO_DISABLE:-1}"
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export MASTER_PORT="${MASTER_PORT:-29500}"
export NNODES="${NNODES:-1}"
export NODE_RANK="${NODE_RANK:-0}"
export GPUS_PER_NODE="${GPUS_PER_NODE:-2}"
export WORLD_SIZE="$((NNODES * GPUS_PER_NODE))"

export CHECKPOINT_DIR="${CHECKPOINT_DIR:-${ROOT_DIR}/generated/megatron_mvp/checkpoints}"
export TENSORBOARD_DIR="${TENSORBOARD_DIR:-${ROOT_DIR}/generated/megatron_mvp/tensorboard}"
export DATA_CACHE_PATH="${DATA_CACHE_PATH:-${ROOT_DIR}/generated/megatron_mvp/data_cache}"
export DATA_PATH="${DATA_PATH:-MOCK}"
mkdir -p "${CHECKPOINT_DIR}" "${TENSORBOARD_DIR}" "${DATA_CACHE_PATH}"

DATA_ARGS=()
if [[ "${DATA_PATH}" == "MOCK" ]]; then
  DATA_ARGS+=(
    --mock-data
    --tokenizer-type NullTokenizer
    --vocab-size 32000
  )
else
  DATA_ARGS+=(
    --tokenizer-type HuggingFaceTokenizer
    --tokenizer-model /ws/musa_framework/models/tiny_llama_smoke
    --vocab-size 32000
    --data-path ${DATA_PATH}
    --split 949,50,1
    --data-cache-path ${DATA_CACHE_PATH}
  )
fi

python3 -m torch.distributed.run     --nproc_per_node "${GPUS_PER_NODE}"     --nnodes "${NNODES}"     --node_rank "${NODE_RANK}"     --master_addr "${MASTER_ADDR}"     --master_port "${MASTER_PORT}"     "${ROOT_DIR}/tools/run_megatron_musa.py" Megatron-LM/pretrain_gpt.py     --rank "${RANK:-0}"     --world-size "${WORLD_SIZE}"     --dist-url "tcp://${MASTER_ADDR}:${MASTER_PORT}"     --use-mcore-models \
    --transformer-impl local \
    --num-layers 2 \
    --hidden-size 64 \
    --ffn-hidden-size 176 \
    --num-attention-heads 8 \
    --seq-length 16 \
    --max-position-embeddings 4096 \
    --position-embedding-type rope \
    --normalization RMSNorm \
    --swiglu \
    --untie-embeddings-and-output-weights \
    --disable-bias-linear \
    --rotary-base 10000 \
    --tensor-model-parallel-size 2 \
    --pipeline-model-parallel-size 1 \
    --micro-batch-size 1 \
    --global-batch-size 1 \
    --bf16 \
    --use-distributed-optimizer \
    --recompute-granularity full \
    --recompute-method uniform \
    --recompute-num-layers 1 \
    --save ${CHECKPOINT_DIR} \
    --load ${CHECKPOINT_DIR} \
    --tensorboard-dir ${TENSORBOARD_DIR} \
    --log-interval 1 \
    --eval-interval 100 \
    --eval-iters 10 \
    --save-interval 100 \
    "${DATA_ARGS[@]}"
