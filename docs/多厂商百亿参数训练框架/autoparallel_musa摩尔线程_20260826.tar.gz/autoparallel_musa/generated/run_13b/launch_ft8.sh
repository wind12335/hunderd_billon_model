#!/usr/bin/env bash
set -euo pipefail

# 8 卡全量微调 colossal-llama2-13B（TP=4, DP=2, PP=1，用户指定）
# 参数来源: /root/workspace/国产卡百亿参数微调.pdf
#   gbs=256, mbs=1, bf16, 激活重计算(full), seq=2048,
#   lr=1e-5 cosine warmup=200, wd=0, clip=1.0, epoch=1 → train_iters=1250
#   TP=1/DP=8 时单卡峰值 ~76GB/80GB 接近 OOM，用户要求改 TP=4/DP=2：
#   每卡只持 1/4 模型(6.25GB)+1/8 优化器分片(~19GB)，基础占用 ~38GB，余量充足。
#   注意 DP=2 后 grad_accum = gbs/(DP*mbs) = 256/2 = 128 个 microbatch/step
#   （DP=8 时是 32），每步更慢但全局 batch=256 语义不变。
# 权重: /ws/musa_framework/generated/ckpt_13b_tp4（TP=4 分片，每 rank 一个 mp_rank_0x，
#       head 按 group 切，40/4=10 heads/rank；vocab 69104/4=17276 整除）
# 数据: /ws/dataset/infinity_7M_core_text_document（690M tokens, 1,483,097 docs）
# 执行: 通过框架执行运行时 tools/run_megatron_musa.py 下放（bootstrap + musa_patch + Megatron）
#
# 短冒烟: TRAIN_ITERS=3 运行 3 步验证 8 卡链路; 默认跑满 1 epoch (1250 步)

ROOT_DIR="/ws/musa_framework"
cd "${ROOT_DIR}"

source "${ROOT_DIR}/scripts/activate_megatron_musa.sh"

export CUDA_DEVICE_MAX_CONNECTIONS="${CUDA_DEVICE_MAX_CONNECTIONS:-1}"
# 减少显存碎片，腾出峰值余量（13B TP=1 单卡 ~75GiB 峰值，80GiB 卡很紧）
export PYTORCH_MUSA_ALLOC_CONF="${PYTORCH_MUSA_ALLOC_CONF:-expandable_segments:True}"
# 关闭 stdout/stderr 缓冲：tee 写日志后用户能立刻 tail 到实时进度
export PYTHONUNBUFFERED=1
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export MASTER_PORT="${MASTER_PORT:-29500}"
export NNODES="${NNODES:-1}"
export NODE_RANK="${NODE_RANK:-0}"
export GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
export WORLD_SIZE="$((NNODES * GPUS_PER_NODE))"

export TRAIN_ITERS="${TRAIN_ITERS:-1250}"
export LR_WARMUP_ITERS="${LR_WARMUP_ITERS:-200}"
export SAVE_DIR="${SAVE_DIR:-${ROOT_DIR}/generated/run_13b/checkpoints}"
export TENSORBOARD_DIR="${TENSORBOARD_DIR:-${ROOT_DIR}/generated/run_13b/tensorboard}"
export DATA_CACHE_PATH="${DATA_CACHE_PATH:-${ROOT_DIR}/generated/run_13b/data_cache}"
mkdir -p "${SAVE_DIR}" "${TENSORBOARD_DIR}" "${DATA_CACHE_PATH}"

echo "[ft8] TRAIN_ITERS=${TRAIN_ITERS} WORLD_SIZE=${WORLD_SIZE}"
echo "[ft8] data: /ws/dataset/infinity_7M_core_text_document"
echo "[ft8] save: ${SAVE_DIR}"

# 断点续训开关：RESUME=1 时从 SAVE_DIR 最新 checkpoint 继续（加载 optimizer/RNG
# 状态，iteration 从保存处续），配合去掉 --finetune。默认 0 = 从头微调。
# 注意：第一个 checkpoint 在 iter 200 才生成；之前中断无点可续，只能重跑。
# 用法: RESUME=1 bash /root/workspace/run_ft8_full.sh
# 续训约束（本版本 scheduler 把 warmup/decay 按 iters*gbs 换算并校验 checkpoint
# 一致性，见 optimizer_param_scheduler.py _check_and_set）：
#   TRAIN_ITERS / LR_WARMUP_ITERS 必须与原始训练一致(1250/200)，压缩即
#   AssertionError "class input value ... and checkpoint value ... do not match"。
#   bootstrap 补丁 #7 已修 dp_zero 续训 KeyError:'step'（跳过 tensors 缺失键）。
if [[ "${RESUME:-0}" == "1" ]]; then
    _LOAD=(--load "${SAVE_DIR}")
    _FINETUNE=()
    _NO_LOAD_OPT=()
    _NO_LOAD_RNG=()
    echo "[ft8] RESUME=1: 从 ${SAVE_DIR} 最新 checkpoint 断点续训"
else
    _LOAD=(--load /ws/musa_framework/generated/ckpt_13b_tp4)
    _FINETUNE=(--finetune)
    _NO_LOAD_OPT=(--no-load-optim)
    _NO_LOAD_RNG=(--no-load-rng)
    echo "[ft8] 从头微调: 加载 /ws/musa_framework/generated/ckpt_13b_tp4"
fi

python3 -m torch.distributed.run \
    --nproc_per_node "${GPUS_PER_NODE}" \
    --nnodes "${NNODES}" \
    --node_rank "${NODE_RANK}" \
    --master_addr "${MASTER_ADDR}" \
    --master_port "${MASTER_PORT}" \
    "${ROOT_DIR}/tools/run_megatron_musa.py" Megatron-LM/pretrain_gpt.py \
    --rank "${RANK:-0}" \
    --world-size "${WORLD_SIZE}" \
    --dist-url "tcp://${MASTER_ADDR}:${MASTER_PORT}" \
    --use-mcore-models \
    --transformer-impl local \
    --num-layers 40 \
    --hidden-size 5120 \
    --ffn-hidden-size 13824 \
    --num-attention-heads 40 \
    --num-query-groups 40 \
    --seq-length 2048 \
    --max-position-embeddings 4096 \
    --position-embedding-type rope \
    --normalization RMSNorm \
    --norm-epsilon 1e-6 \
    --swiglu \
    --untie-embeddings-and-output-weights \
    --disable-bias-linear \
    --rotary-base 10000 \
    --tensor-model-parallel-size 4 \
    --pipeline-model-parallel-size 1 \
    --micro-batch-size 1 \
    --global-batch-size "${GLOBAL_BATCH_SIZE:-256}" \
    --bf16 \
    --use-distributed-optimizer \
    --grad-reduce-in-bf16 \
    --recompute-granularity full \
    --recompute-method uniform \
    --recompute-num-layers 40 \
    --train-iters "${TRAIN_ITERS}" \
    --lr 1e-5 \
    --min-lr 1e-6 \
    --lr-decay-style cosine \
    --lr-warmup-iters "${LR_WARMUP_ITERS}" \
    --weight-decay 0 \
    --clip-grad 1.0 \
    --adam-beta1 0.9 \
    --adam-beta2 0.95 \
    --attention-dropout 0.0 \
    --hidden-dropout 0.0 \
    --init-method-std 0.02 \
    --tokenizer-type HuggingFaceTokenizer \
    --tokenizer-model /ws/model \
    --vocab-size 69104 \
    --make-vocab-size-divisible-by 1 \
    --data-path /ws/dataset/infinity_7M_core_text_document \
    --split 949,50,1 \
    --data-cache-path "${DATA_CACHE_PATH}" \
    --ckpt-format torch \
    "${_FINETUNE[@]}" \
    "${_LOAD[@]}" \
    "${_NO_LOAD_OPT[@]}" \
    "${_NO_LOAD_RNG[@]}" \
    --save "${SAVE_DIR}" \
    --save-interval "${SAVE_INTERVAL:-50}" \
    --tensorboard-dir "${TENSORBOARD_DIR}" \
    --log-interval 1 \
    --eval-interval 1000 \
    --eval-iters 0
