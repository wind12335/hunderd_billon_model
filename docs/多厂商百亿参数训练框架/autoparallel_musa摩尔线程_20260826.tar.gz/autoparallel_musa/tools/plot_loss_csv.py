#!/usr/bin/env python3
"""读 loss CSV，画 iteration-loss 曲线 PNG。

用法:
  python3 plot_loss_csv.py --csv /ws/ft8_loss.csv --out /ws/loss_curve.png

CSV 两列: iteration, lm_loss（可由 tools/log_to_csv.py 生成）。
纯 matplotlib，无 torch 依赖，无头环境直接输出 PNG。
"""

from __future__ import annotations

import argparse
import csv

import matplotlib

matplotlib.use("Agg")  # 无头环境，只输出 PNG
import matplotlib.pyplot as plt  # noqa: E402

TITLE = "colossal-llama2-13B Finetune Loss (TP=4/DP=2, gbs=256)"


def main() -> int:
    ap = argparse.ArgumentParser(description="loss CSV → 曲线 PNG")
    ap.add_argument("--csv", default="/ws/ft8_loss.csv", help="CSV 路径")
    ap.add_argument("--out", default="/ws/loss_curve.png", help="输出 PNG 路径")
    args = ap.parse_args()

    iters: list[int] = []
    losses: list[float] = []
    with open(args.csv, newline="") as f:
        for row in csv.DictReader(f):
            iters.append(int(row["iteration"]))
            losses.append(float(row["lm_loss"]))

    if not iters:
        print(f"CSV 为空或没有数据行: {args.csv}", flush=True)
        return 1

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=120)
    ax.plot(iters, losses, marker=".", linestyle="-", color="#d62728", lw=1.2, ms=4)
    ax.set_xlabel("iteration")
    ax.set_ylabel("lm loss")
    ax.set_title(TITLE)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(left=0)
    lo, hi = min(losses), max(losses)
    pad = (hi - lo) * 0.08 or 0.5
    ax.set_ylim(lo - pad, hi + pad)
    ax.annotate(
        f"{losses[-1]:.3f}",
        (iters[-1], losses[-1]),
        textcoords="offset points",
        xytext=(8, 6),
        fontsize=9,
        color="#d62728",
    )
    fig.tight_layout()
    fig.savefig(args.out)
    plt.close(fig)

    print(f"已绘制 {len(iters)} 个点 -> {args.out}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
