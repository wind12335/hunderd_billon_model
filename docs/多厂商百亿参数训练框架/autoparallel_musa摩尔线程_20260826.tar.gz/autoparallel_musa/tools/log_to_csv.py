#!/usr/bin/env python3
"""从 Megatron 训练日志提取 lm loss，写入 CSV。

用法:
  python3 log_to_csv.py --log /ws/ft8_full.log --csv /ws/ft8_loss.csv

输出 CSV 两列: iteration, lm_loss
纯 re，无第三方依赖，训练结束后（或任意时刻）随时可跑，幂等覆盖。
"""

from __future__ import annotations

import argparse
import csv
import re

# 匹配日志行: "iteration 123/1250 | ... | lm loss: 1.275940E+01 | ..."
LINE_RE = re.compile(
    r"iteration\s+(\d+)\s*/\s*(\d+).*?lm loss:\s*"
    r"([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)"
)


def main() -> int:
    ap = argparse.ArgumentParser(description="Megatron 日志 → loss CSV")
    ap.add_argument("--log", default="/ws/ft8_full.log", help="训练日志路径")
    ap.add_argument("--csv", default="/ws/ft8_loss.csv", help="输出 CSV 路径")
    args = ap.parse_args()

    rows: list[tuple[int, float]] = []
    with open(args.log, "r", errors="replace") as f:
        for line in f:
            m = LINE_RE.search(line)
            if m:
                rows.append((int(m.group(1)), float(m.group(3))))

    with open(args.csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["iteration", "lm_loss"])
        w.writerows(rows)

    print(f"已从 {args.log} 提取 {len(rows)} 步 loss -> {args.csv}", flush=True)
    if rows:
        print(f"首: iter={rows[0][0]} loss={rows[0][1]:.4f}  "
              f"末: iter={rows[-1][0]} loss={rows[-1][1]:.4f}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
