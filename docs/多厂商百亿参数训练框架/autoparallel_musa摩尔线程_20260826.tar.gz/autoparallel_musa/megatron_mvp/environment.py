"""运行环境检测。"""

from __future__ import annotations

import torch

from megatron_mvp.types import DeviceInfo
from megatron_mvp.types import RuntimeEnvironment


def detect_runtime_environment() -> RuntimeEnvironment:
    """检测当前海光/ROCm 运行环境。"""
    if not torch.cuda.is_available() or torch.cuda.device_count() <= 0:
        raise RuntimeError("当前未检测到可用的 GPU/DCU 设备，无法进行 Megatron 并行搜索。")

    devices: list[DeviceInfo] = []
    for index in range(torch.cuda.device_count()):
        props = torch.cuda.get_device_properties(index)
        devices.append(
            DeviceInfo(
                index=index,
                name=props.name,
                total_memory_bytes=int(props.total_memory),
                multi_processor_count=getattr(props, "multi_processor_count", None),
            )
        )

    primary_device = devices[0]
    # MUSA(摩尔线程): torch_musa 已把 cuda 垫片挂到 torch.cuda.*，能走上面的检测，
    # 但 accelerator_type 报告值要如实区分，避免在 MUSA 上误报成 cuda。
    if getattr(torch, "musa", None) is not None and torch.musa.is_available():
        accelerator_type = "musa"
    elif getattr(torch.version, "hip", None):
        accelerator_type = "hip"
    else:
        accelerator_type = "cuda"
    return RuntimeEnvironment(
        accelerator_type=accelerator_type,
        device_count=len(devices),
        devices=devices,
        primary_device_name=primary_device.name,
        primary_device_memory_bytes=primary_device.total_memory_bytes,
        torch_version=str(torch.__version__),
        hip_version=getattr(torch.version, "hip", None),
    )

