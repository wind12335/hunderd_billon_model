import torch
import torch.nn.functional as F


class MusaSwiGLUFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input, fp8_input_store, cpu_offload_input):
        input_for_backward = input.to(torch.float8_e4m3fn) if fp8_input_store else input
        if cpu_offload_input:
            input_for_backward.activation_offloading = True
        ctx.save_for_backward(input_for_backward)
        ctx.ori_input_dtype = input.dtype
        ctx.fp8_input_store = fp8_input_store
        return torch.ops.aten._fused_swiglu_forward(input)

    @staticmethod
    def backward(ctx, grad_output):
        input = ctx.saved_tensors[0]
        input = input.to(ctx.ori_input_dtype) if ctx.fp8_input_store else input
        return torch.ops.aten._fused_swiglu_backward(grad_output, input), None, None


import megatron.core.fusions.fused_bias_swiglu
megatron.core.fusions.fused_bias_swiglu.SwiGLUFunction = MusaSwiGLUFunction

# import sys
# for k in sys.modules:
#     if k.startswith('megatron.core.fusions.fused_bias_swiglu'):
#         for target in ['bias_swiglu_impl']:
#             if getattr(sys.modules[k], target, None):
#                 print(f'target is {target}')
#                 setattr(sys.modules[k], target, bias_swiglu_impl)
