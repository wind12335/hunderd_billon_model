#!/usr/bin/env bash
set -euo pipefail

# 8 卡天垓150(BI-V150, 32GB) 全量微调 colossal-llama2-13B
#   （TP=4, PP=2, DP=1 + 优化器 CPU offload）
# 参数来源: /private/国产卡百亿参数微调.pdf + 摩尔线程版 launch_ft8.sh 对齐口径
#   gbs=256, mbs=1, bf16, 激活重计算(full), seq=2048,
#   lr=1e-5 cosine warmup=200, min-lr=1e-6, wd=0, clip=1.0, epoch=1
#   → train_iters=1250（≈1 epoch；resume 断点续训时末步显示 1249/1250 属正常）
#
# ⚠️ 为何必须 --optimizer-cpu-offload —— 32GB 卡实测（2026-09-23）：
#   8 卡上 TP×PP=8 ⇒ DP=1，DistributedOptimizer 无分片收益。纯 GPU 拓扑
#   全部 OOM，且 OOM 点相同（apex FusedAdam 首步懒初始化 exp_avg 时，
#   allocated 已达 ~30.9GB，而单卡 PyTorch 可用上限 ~30.75GB）：
#     TP=4/DP=2 : 31.29GB → OOM      TP=8/DP=1 : 31.07GB → OOM
#     TP=4/PP=2 : 30.94GB → OOM      TP=2/PP=2/DP=2 : 31.02GB → OOM
#   根因：bf16 训练下 dist-optimizer 的 fp32 脚手架（master 参数 + 梯度
#   上转 buffer + m/v）≈ 18.5B/param × 每 rank 1.675B 参数 ≈ 31GB，与
#   拓扑无关。PDF 口径"天垓(32GB) 8 卡装不下 14B、最低 16 卡"与此互证。
#   解法：Megatron 原生 --optimizer-cpu-offload（HybridDeviceOptimizer），
#   fp32 优化器状态驻留 CPU（本机 1TB RAM），实测稳态仅 ~6.5GB/卡、
#   峰值 ~13.7GB/卡，余量充足。代价是每步 D2H/H2D ~6.7GB×2 ≈ 1-2s，
#   相对每步数百秒的训练时长可忽略。
#   依赖 bootstrap 两个补丁：is_te_min_version None 修复（offload 必经）、
#   clip_grad bf16 改 torch foreach（corex apex 无 bf16 multi_tensor_scale）。
#
# 权重: ${ROOT_DIR}/generated/ckpt_13b_tp4pp2（由 tools/convert_hf_to_mcore.py
#       --tensor-model-parallel-size 4 --pipeline-model-parallel-size 2 从
#       /ws/model 的 HF colossal-llama2-13B 转出）
# 数据: /ws/dataset/infinity_7M_core_text_document（~690M tokens, ~1.48M docs）
# 执行: 通过框架执行运行时 tools/run_megatron_corex.py 下放
#       （bootstrap + te_stub + Megatron 上游 core_v0.14.0rc2）
#
# flash-attn: verify_forward_equiv.py 已证 CoreAttention(纯torch)路径与 HF 端到端
#   一致(logits cos 0.9998)；但开 --use-flash-attn 的 3 步真实数据冒烟 loss=12.5
#   (随机初始化水平)，A/B 后确认为 corex flash_attn 2.6.3 集成路径数值问题。
#   默认 COREX_USE_FLASH_ATTN=0 走 CoreAttention（显存余量充足：峰值 ~15GB/32GB，
#   softmax 增量 ~84MB/层, full recompute 下同时仅 1 层）。
export COREX_USE_FLASH_ATTN="${COREX_USE_FLASH_ATTN:-0}"

# 短冒烟: TRAIN_ITERS=3 运行 3 步验证 8 卡链路; 默认跑满 1 epoch (1250 步)
# 曲线: TensorBoard(同时记录 loss 与 lr) + 训练后 log_to_csv.py/plot_loss_csv.py
#   python3 tools/log_to_csv.py  --log /ws/ft8_full.log --csv /ws/ft8_loss.csv
#   python3 tools/plot_loss_csv.py --csv /ws/ft8_loss.csv --out /ws/loss_lr_curve.png

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${ROOT_DIR}"

source "${ROOT_DIR}/scripts/activate_megatron_corex.sh"

export CUDA_DEVICE_MAX_CONNECTIONS="${CUDA_DEVICE_MAX_CONNECTIONS:-1}"
# 减少显存碎片，腾出峰值余量（32GB 卡 31.7GB 基础占用下关键）
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
# 关闭 stdout/stderr 缓冲：tee 写日志后能立刻 tail 到实时进度
export PYTHONUNBUFFERED=1
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export MASTER_PORT="${MASTER_PORT:-29500}"
export NNODES="${NNODES:-1}"
export NODE_RANK="${NODE_RANK:-0}"
export GPUS_PER_NODE="${GPUS_PER_NODE:-8}"
export WORLD_SIZE="$((NNODES * GPUS_PER_NODE))"

export TP_SIZE="${TP_SIZE:-4}"
export PP_SIZE="${PP_SIZE:-2}"
export LAYERS_PER_STAGE=$((40 / PP_SIZE))
export TRAIN_ITERS="${TRAIN_ITERS:-1250}"
export LR_WARMUP_ITERS="${LR_WARMUP_ITERS:-200}"
# 大产物一律放 /workspace（/private 是 30GB NFS，仅放源码/模型/原始数据集）
export WORK_DIR="${WORK_DIR:-/workspace/ft13b}"
export SAVE_DIR="${SAVE_DIR:-${WORK_DIR}/run/checkpoints}"
export TENSORBOARD_DIR="${TENSORBOARD_DIR:-${WORK_DIR}/run/tensorboard}"
export DATA_CACHE_PATH="${DATA_CACHE_PATH:-${WORK_DIR}/data/cache}"
export MODEL_DIR="${MODEL_DIR:-/private/model/llama2-13b}"
mkdir -p "${SAVE_DIR}" "${TENSORBOARD_DIR}" "${DATA_CACHE_PATH}"

# checkpoint 滚动保留最新 3 个（bootstrap 补丁 _rotate_persistent_checkpoints）
export COREX_KEEP_LAST_CKPT="${COREX_KEEP_LAST_CKPT:-3}"

# 加载基座权重路径（默认 TP=4/PP=2 分片版；改 TP/PP 后须先转出对应版本）
export BASE_CKPT="${BASE_CKPT:-${WORK_DIR}/ckpt_13b_tp${TP_SIZE}pp${PP_SIZE}}"
export DATA_PREFIX="${DATA_PREFIX:-${WORK_DIR}/data/infinity_7M_core_text_document}"

echo "[ft8] TRAIN_ITERS=${TRAIN_ITERS} WORLD_SIZE=${WORLD_SIZE} TP=${TP_SIZE} PP=${PP_SIZE}"
echo "[ft8] data: ${DATA_PREFIX}"
echo "[ft8] base ckpt: ${BASE_CKPT}"
echo "[ft8] save: ${SAVE_DIR} (keep last ${COREX_KEEP_LAST_CKPT})"

# 断点续训开关：RESUME=1 时从 SAVE_DIR 最新 checkpoint 继续（加载 optimizer/RNG
# 状态，iteration 从保存处续），配合去掉 --finetune。默认 0 = 从头微调。
# 续训约束（scheduler 会校验 checkpoint 一致性）：
#   TRAIN_ITERS / LR_WARMUP_ITERS 必须与原始训练一致(1250/200)，压缩即
#   AssertionError。bootstrap 已修 dp_zero 续训 KeyError:'step'。
if [[ "${RESUME:-0}" == "1" ]]; then
    _LOAD=(--load "${SAVE_DIR}")
    _FINETUNE=()
    _NO_LOAD_OPT=()
    _NO_LOAD_RNG=()
    echo "[ft8] RESUME=1: 从 ${SAVE_DIR} 最新 checkpoint 断点续训"
else
    _LOAD=(--load "${BASE_CKPT}")
    _FINETUNE=(--finetune)
    _NO_LOAD_OPT=(--no-load-optim)
    _NO_LOAD_RNG=(--no-load-rng)
    echo "[ft8] 从头微调: 加载 ${BASE_CKPT}"
fi

# flash-attn 开关（默认关：corex flash_attn 训练路径数值异常，见顶部注释）
if [[ "${COREX_USE_FLASH_ATTN}" == "1" ]]; then
    _FA=(--use-flash-attn)
    echo "[ft8] attention: flash-attn (COREX_USE_FLASH_ATTN=1)"
else
    _FA=()
    echo "[ft8] attention: CoreAttention 纯torch路径 (已验证与 HF 等价)"
fi

python3 -m torch.distributed.run \
    --nproc_per_node "${GPUS_PER_NODE}" \
    --nnodes "${NNODES}" \
    --node_rank "${NODE_RANK}" \
    --master_addr "${MASTER_ADDR}" \
    --master_port "${MASTER_PORT}" \
    "${ROOT_DIR}/tools/run_megatron_corex.py" Megatron-LM/pretrain_gpt.py \
    --rank "${RANK:-0}" \
    --world-size "${WORLD_SIZE}" \
    --dist-url "tcp://${MASTER_ADDR}:${MASTER_PORT}" \
    --use-mcore-models \
    --transformer-impl local \
    --num-layers 40 \
    --hidden-size 5120 \
    --ffn-hidden-size 13824 \
    --num-attention-heads 40 \
    --num-query-groups 40 \
    --seq-length 2048 \
    --max-position-embeddings 4096 \
    --position-embedding-type rope \
    --normalization RMSNorm \
    --norm-epsilon 1e-6 \
    --no-persist-layer-norm \
    --swiglu \
    --untie-embeddings-and-output-weights \
    --disable-bias-linear \
    --no-rope-fusion \
    --rotary-base 10000 \
    "${_FA[@]}" \
    --tensor-model-parallel-size "${TP_SIZE}" \
    --pipeline-model-parallel-size "${PP_SIZE}" \
    --micro-batch-size 1 \
    --global-batch-size "${GLOBAL_BATCH_SIZE:-256}" \
    --bf16 \
    --use-distributed-optimizer \
    --grad-reduce-in-bf16 \
    --optimizer-cpu-offload \
    --use-precision-aware-optimizer \
    --recompute-granularity full \
    --recompute-method uniform \
    --recompute-num-layers "${LAYERS_PER_STAGE}" \
    --train-iters "${TRAIN_ITERS}" \
    --lr 1e-5 \
    --min-lr 1e-6 \
    --lr-decay-style cosine \
    --lr-warmup-iters "${LR_WARMUP_ITERS}" \
    --weight-decay 0 \
    --clip-grad 1.0 \
    --adam-beta1 0.9 \
    --adam-beta2 0.95 \
    --attention-dropout 0.0 \
    --hidden-dropout 0.0 \
    --init-method-std 0.02 \
    --tokenizer-type HuggingFaceTokenizer \
    --tokenizer-model "${MODEL_DIR}" \
    --vocab-size 69104 \
    --make-vocab-size-divisible-by 1 \
    --data-path "${DATA_PREFIX}" \
    --split 949,50,1 \
    --data-cache-path "${DATA_CACHE_PATH}" \
    --ckpt-format torch \
    "${_FINETUNE[@]}" \
    "${_LOAD[@]}" \
    "${_NO_LOAD_OPT[@]}" \
    "${_NO_LOAD_RNG[@]}" \
    --save "${SAVE_DIR}" \
    --save-interval "${SAVE_INTERVAL:-50}" \
    --tensorboard-dir "${TENSORBOARD_DIR}" \
    --log-interval 1 \
    --eval-interval 1000 \
    --eval-iters 0
