# yarn rope fusion(yarn rotary embeding)

## 作用
对MLA中的yarn rope采用融合算子进行加速

## 解决思路
q_embed = (q * cos) + (rotate_half(q) * sin)
k_embed = (k * cos) + (rotate_half(k) * sin)
上述操作涉及的memory bound小算子操作较多，采用算子融合的方式加速计算，减少memory bound

## 使用方法

--yarn-rope-fusion

## 优点
加速计算，对模型e2e提升1.5%~2%

## 缺点
无

## 精度影响
无