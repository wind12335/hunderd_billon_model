# nvtx

## 作用
用于慢节点检测中每个节点的耗时统计

## 使用方法
--nvtx
--nvtx-level [0,1,2] 

## 解释
高level将包括低level的统计
### --nvtx-level 0[default]
仅统计训练过程中每一步的forward and backward、optimizer 、loss
### --nvtx-level 1 
细化统计每一步forward与backward
### --nvtx-level 2
细化统计warm up , forward,backward, cool down,通信耗时

## 局限
level 2下，通信受到overlap的影响，可能存在偏差。建议使用level 0 和level 1