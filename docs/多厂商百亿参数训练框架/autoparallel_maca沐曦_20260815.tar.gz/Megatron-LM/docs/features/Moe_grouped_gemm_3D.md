# grouped gemm 3D

## 作用
使用3D weights初始化，省去forward时reshape的步骤，提升性能。

## 使用方法

--moe-grouped-gemm-3D

## 优点
提升性能

## 缺点
checkpoint 存储文件较大

## 精度影响
无