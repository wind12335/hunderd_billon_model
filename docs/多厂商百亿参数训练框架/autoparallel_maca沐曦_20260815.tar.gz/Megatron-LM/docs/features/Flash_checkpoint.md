# Dlrover flash checkpoint

## 原理参考
https://github.com/intelligent-machine-learning/dlrover/blob/master/docs/blogs/flash_checkpoint_cn.md

## 作用
    异步持久化：DLRover Flash Checkpoint 采用同步将训练状态写到共享内存，然后异步从共享内存写到存储系统，将训练阻塞时间降低到最小。
    断点续存：故障发生后，DLRover 可以紧急将内存中的 Checkpoint 持久化到存储中。防止 Checkpoint 数据丢失，减少训练迭代时间的浪费。
    内存热加载：如果非机器宕机故障，DLRover 可以直接重启训练进程，这时可以直接从主机内存中加载 Checkpoint，省去读存储文件的 IO 开销。

## 使用方法
    --dlrover-flash-save #save_checkpoint接口使用dlrover flash checkpoint实现
    --dlrover-flash-load #load_checkpoint接口使用dlrover flash checkpoint实现
    当前每个--save-interval保存到cpu memory中，每4次save_interval保存到disk中

需要安装DC团队的dlrover，并用dlrover-run起任务（不用torch-run),具体示例如下：
### 设置dlrover master service的端口和地址
    export POD_IP=10.107.204.147
    export DLROVER_MASTER_ADDR=10.107.204.147:12355
### 各节点分别设置rank ID: 
    export NODE_RANK=x
### 运行训练脚本并设置分布式的端口和地址
    dlrover-run --nnodes=2 --nproc-per-node=8 --master_addr 10.107.204.147 --master_port 12354 ./train.py 

## 优点
    同上述作用模块

## 缺点
无

## 精度影响
无