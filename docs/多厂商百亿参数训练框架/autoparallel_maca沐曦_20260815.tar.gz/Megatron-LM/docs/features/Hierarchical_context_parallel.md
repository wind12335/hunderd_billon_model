# Hierarchical context parallel

## 作用
一种分层实现的上下文并行（CP）方法用于注意力机制。
它在低级 CP 组中使用 A2A 通信（节点内，例如，通过 MetaLink），
并在高级 CP 组中使用 P2P 通信（节点间，例如，通过 IBLink）。

"p2p"：在环拓扑结构中使用 P2P 通信交换 KV 分块。P2P 是异步的，并且可以与注意力计算重叠执行。
"a2a"：类似于 DeepSpeed Ulysses，将注意力头分散到 CP 组中，并聚合以获取完整的 QKV 序列。

## 解决思路

首先介绍下p2p(Ring-Attention)和a2a(DS-Ulysses)的context 并行下的行为对比：
### 通信量：Ulysses完胜。
DS-Ulysses三次All2All通信量3xO(Nxd)。
Ring-Attention ：N/P/c x (P-1)/PxO(Nxd)=O(N^2xd/(Pxc))，外层循环每个GPU需要N/P/c次迭代，内层循环每个GPU收发(P-1)/P x O(Nxd)数据。通信会随着序列长度增长而平方增长。所以非常依赖和计算重叠。
### 通信方式：Ring-Attention更鲁棒。
DS-Ulysses需要All2All通信，对底层XCCL实现和网络硬件拓扑要求比较。一般All2All跨机器涉及拥塞控制，带宽比较差。
Ring-Attention需要P2P通信，对网络需求很低。
### 内存使用：二者近似
二者Q、K、V显存消耗一致，对于QK计算结果intermediate tensor也都可以和FlashAttention等memory efficient attention方法兼容。二者也都可以和ZeRO、TP等其他并行方式兼容，所以我认为二者内存消耗类似。
### 网络硬件泛化型：Ring-Attention更好
Ulysses没有重叠All2All和计算，不过这个并不是不可以做。
Ring-Attention重叠P2P和计算，对分块大小c需要调节。
### 模型结构泛化性：Ring-Attention更好
Ulysses会受到head数目限制，导致无法完成切分。尤其是和TP结合，有序列并行degree * 张量并行degree <= head_cnt的限制。
Ring-Attention对网络结构参数不敏感。
### 输入长度泛化性：Ulysses更好。
Ring-Attention处理变长输入很难处理，Ulysses无所谓。

Ulysses和Ring可以组成一个混合序列并行方案。同时克服并行度<=num_head的限制，和避免P2P低效带宽利用。

## 使用方法

  --context-parallel-size: 8
  --cp-comm-type: a2a+p2p
  --hierarchical-context-parallel-sizes: 2 4
   num_head 要能被 tp_size * hierarchical_context_parallel_sizes[0] 整除。

## 优点
Ulysses和Ring可以组成一个混合序列并行方案。同时克服并行度<=num_head的限制，和避免P2P低效带宽利用。
节点内的context parallel用A2A（DS ulysess）的实现，节点间的context parallel用P2P(ring attention)的实现

## 缺点
无

## 精度影响
无