# Moe_reduce_memory

## 作用
    对moe模型部分支持重计算功能

## 解决思路
    对moe模型部分，采用几个level的重计算功能

## 使用方法
    --moe-reduce-memory "level0" ，default为"diable",表示关闭该功能；level0对激活函数，permute等开启重计算；level1在level0的基础上增加shared expert和moe FC1的重计算
    --moe-reduce-memory-num-layers 4，每个pp/vpp stage开启的层数，仅在level1时生效
    --moe-reduce-memory-num-layers-list 4 3 2, 每个pp/vpp stage开启的不均匀层数，仅在level1时生效，与--moe-reduce-memory-num-layers选择一个使用即可
    当前仅支持与--moe-alltoall-overlap-comm或者dualpipev联合使用

## 优点
    根据显存状态，在尽可能减少性能损失的情况下，减少显存使用

## 缺点


## 精度影响
无