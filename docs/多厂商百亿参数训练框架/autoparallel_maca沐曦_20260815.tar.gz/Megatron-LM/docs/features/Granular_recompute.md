# 细粒度重计算：granular-recompute-norm
（重计算，优先使用细粒度granular-recompute-norm，接着使用细粒度granular-recompute-activation-function，最后使用全量重计算，三者可以结合使用）

## 作用
特性支持了Norm层的重计算，norm层计算量小，开重计算相比全量重计算性能更好。使用场景：仅需开一到两层重计算的模型，可以用norm重计算来代替，相比全量重计算，在节省相同显存下，性能更好。也可以作为全量重计算的补充

## 使用方法

--recompute-granularity full 需要打开

--recompute-method block 需要打开

--granular-recompute-norm 打开这个参数，就默认所有norm开启重计算

--granular-recompute-norm-num-layers 均匀norm重计算，设置为N，则表示每个stage上N个layer开启norm重计算

--granular-recompute-norm-num-layers-list 不均匀norm重计算，用法与不均匀全量重计算类似

example:

--recompute-granularity full 

--recompute-method block 

--recompute-num-layers-list 2 2 3 3

--granular-recompute-norm 

--granular-recompute-norm-num-layers-list 1 1 2 2

则表示前两个stage开启2层全量重计算+1层norm 重计算，后两个stage 开启3层全量重计算+2层norm 重计算

## 优点
相同显存占用下，性能相对于recompute有较大优势。稍慢于完全不开重计算场景。

## 缺点
无

## 精度影响
无

# 细粒度重计算：granular-recompute-activation-function

## 作用
特性支持了激活函数层的重计算，激活函数层计算量小，开重计算相比全量重计算性能更好。使用场景：仅需开一到两层重计算的模型，可以用激活函数重计算来代替，相比全量重计算，在节省相同显存下，性能更好。也可以作为全量重计算的补充

## 使用方法

--recompute-granularity full 需要打开

--recompute-method block 需要打开

--granular-recompute-activation-func 打开这个参数，就默认所有激活函数 层开启重计算

--granular-recompute-activation-func-num-layers 均匀激活函数 层重计算，设置为N，则表示每个stage上N个layer开启激活函数 层重计算

--granular-recompute-activation-func-num-layers-list 不均匀激活函数 层重计算，用法与不均匀全量重计算类似

example:

--recompute-granularity full 

--recompute-method block 

--recompute-num-layers-list 2 2 3 3

--granular-recompute-activation-func 

--granular-recompute-activation-func-num-layers-list 1 1 2 2

则表示前两个stage开启2层全量重计算+1层激活函数 层重计算，后两个stage 开启3层全量重计算+2层激活函数 层重计算

## 优点
相同显存占用下，性能相对于recompute有较大优势。稍慢于完全不开重计算场景。

## 缺点
无

## 精度影响
无

# megatron官方selective细粒度重计算
    --recompute-granularity selective
    --recompute-modules 设置如下
    group.add_argument('--recompute-modules', nargs='*', type=str, default=None,
                       help='The submodules to recompute. '
                       'choices: "core_attn", "moe_act", "layernorm", "mla_up_proj", "mlp", "moe". '
                       'default: ["core_attn"].'
                       '"core_attn": recompute the core attention part of the transformer layer. '
                       '"moe_act": recompute the MoE MLP activation function. '
                       '"layernorm": recompute the input_layernorm and pre_mlp_layernorm. '
                       '"mla_up_proj": recompute the MLA up projection and RoPE applying parts.'
                       '"mlp": recompute the dense MLP layer.'
                       '"moe": recompute the MoE layer.'
                       '"moe_act", "layernorm", and "mla_up_proj" use output-discarding checkpointing, '
                       '"core_attn", "mlp", and "moe" uses normal checkpointing.')
    不支持设置layer数
    