# batched gemm

## 作用
将moe中多个experts的mlp经过drop token和padding后合并计算

## 使用方法

--moe-expert-capacity-factor 1.0

--moe-pad-expert-input-to-capacity

--moe-batched-gemm

## 优点
最高效moe-mlp的利用率

## 缺点
仅在pad情况下可以使用

## 精度影响
小（需要drop token）