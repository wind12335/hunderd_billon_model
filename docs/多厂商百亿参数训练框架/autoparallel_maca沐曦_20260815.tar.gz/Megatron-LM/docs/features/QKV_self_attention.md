# QKV self-attention(self attention优化)

## 作用
    对self-attention部分，减冗余操作。

    对gqa场景的模型，qkv proj之后，不做split再repeat操作，直接采用融合算子repeat

    对非gqa模型，如llama2-7B，GPT-moe-567B，qkv proj之后直接适当reshape后给flash attn（qkv-packed）进行计算

## 使用方法
--use-qkv-flash-attn
--use-flash-fusion 结合flash fusion开启融合算子

可同时增加环境变量，启用汇编版本的flash-attn，加速训练

export MHA_USE_BLAS=ON #flash attn采用汇编算法，性能相关

export MHA_BWD_NO_ATOMIC_F64=1 #关闭flash attn汇编高精度算法，性能相关

## 优点
性能提升，gqa模型，性能提升3%左右，非qga模型性能提升5%+（llama2-7B,  3628 tgs ->3900 tgs, C500）

## 缺点
context parallel、MLA结构、qk-layernorm和该特性不兼容

## 精度影响
无