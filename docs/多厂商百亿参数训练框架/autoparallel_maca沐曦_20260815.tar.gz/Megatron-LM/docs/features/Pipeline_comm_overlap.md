# pipeline parallel comm overlap with computation PP通信计算并行优化

## 问题1
在interleavd pp（VPP）场景，会带来更多的send/recv，并且会有计算并行；但是并行仅存在于Steady（1F1B）阶段

## 作用1
增加warm up与flush(cold down)阶段pp send/recv通信与计算的并行

## 使用方法1
--overlap-p2p-communication-warmup-flush #增加warm up与flush(cold down)阶段pp send/recv通信与计算的并行
可以额外开启--use-sdma-pp-comm，将pp通信采用sdma，减少计算通信资源竞争

## 优点1
提升性能，llama2-7B, pp4dp2, gbs8，单机版本，性能提升1.1%

## 缺点1
无

## 精度影响1
无

## 问题2
在interleavd pp（VPP）场景，当开启dp overlap，dp通信和vpp通信会较频繁，存在资源竞争

## 作用2
减少Forward中的部分all gather通信，将其移动到optimizer计算阶段

## 使用方法2
--overlap-param-gather-with-optimizer-step #减少Forward中的部分all gather通信，将其移动到optimizer计算阶段
--ckpt-format torch #不支持分布式ckpt
可以额外开启--use-sdma-pp-comm，将pp通信采用sdma，减少计算通信资源竞争

## 优点2
提升性能，llama2-7B, pp4dp2, gbs8，单机版本，性能提升1.3%

## 缺点2
不支持分布式ckpt, torch_dist和zarr

## 精度影响2
无