# optimizer_cpu_offload 

## 作用
将optimizer offload到cpu上，以节省显存  

## 使用方法

--optimizer-cpu-offload  开启offload  

--optimizer-offload-fraction  控制offload到cpu上的参数的比例，默认1.0，即100%  

--use-torch-optimizer-for-cpu-offload  使用torch自带的optimizer offload

--overlap-cpu-optimizer-d2h-h2d   overlap传输和计算  


--no-pin-cpu-grads    grads不使用pin memroy（默认使用pin memroy），加速h2d/d2h，但是显存增加
--no-pin-cpu-params   params不使用pin memroy（默认使用pin memroy），加速h2d/d2h，但是显存增加


## 优点
节省显存  

## 缺点
对CPU性能要求高，当CPU性能差时影响较大  
--optimizer-offload-fraction不支持--accumulate-bf16  

## 精度影响
无