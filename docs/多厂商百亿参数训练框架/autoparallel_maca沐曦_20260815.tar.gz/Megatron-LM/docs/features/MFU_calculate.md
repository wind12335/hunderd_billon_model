# 打印mfu

## 作用
打印逐step的mfu

## 使用方法

--device-tflops  单卡flops，C500是xxx，C550是xxx

## 优点
比模型参数*6的方式更精确

## 缺点
无

## 精度影响
不影响