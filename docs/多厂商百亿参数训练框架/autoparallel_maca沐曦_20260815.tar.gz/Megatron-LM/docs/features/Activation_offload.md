# attention-offload(普通activation offload)

## 作用
利用设备内存和CPU内存来存放激活值，在梯度反传的同时从CPU内存预取激活值来减少重计算，充分利用H2D高带宽的优势以网补存、以网强算，提升MFU，加速大模型的训练。

## 使用方法

--attention-offload（如果显存差的不多，可以单独使用）

可以指定其他模块进行offload,例如linput_layernorm，此时加入参数

--offload-modules input_layernorm,self_attention,pre_mlp_norm

目前支持的模块包括self_attention【默认】，input_layernorm,pre_mlp_norm【optional】

支持与重计算一起使用，例如

--attention-offload 

--recompute-granularity full 

--recompute-method block 

--recompute-num-layers 2 

## 优点
相同显存占用下，性能相对于recompute有较大优势。稍慢于完全不开重计算场景。

## 缺点
依赖torch2.1，后面megatron的镜像也会优先切torch2.1

## 精度影响
无

# granular-attention-offload(细粒度activation offload)

## 作用
大部分应用场景中，显存不足现象在不同stage存在不均衡现象，通常stage0的激活生命周期更长且开销更大，而最后一个stage的激活生命周期非常短且开销较小，granular attention offload 可以控制不同stage offload不同的粒度，更加精确的优化显存开销

## 使用方法

【说明】：假设只有第一个stage 显存溢出，

--attention-offload

--granular-attention-offload-num-stage 1 

【说明】：假设第一个stage offload之后，发现显存充足，此时可以减少offload 的层数，例如，模型的第0,1层不需要offload

--attention-offload

--granular-attention-offload-num-stage 1 

--no-offload-layers 0,1

【说明】：假设第一个stage和第二个stage显存不足，stage0需要offload 8层，而stage1需要offload2层，若num layer per pp=10，则stage0不需要offload0，1层，stage1不需要offload 10,11,12,13,14,15,16,17

--attention-offload

--granular-attention-offload-num-stage 2

--no-offload-layers 0,1,10,11,12,13,14,15,16,17

【说明】：假设stage0差非常多显存，stage1差一点显存，而offload attention收益大于layernorm，此时可以第一个stage offload 全部attention+全部 layernorm,stage1仅需要offload 5层attention,其余stage不需要offload

--暂未支持

## 优点
减少相同显存时，性能开销比attention offload 更小，优于attention-offload与重计算

## 缺点
调试更复杂，依赖torch2.1，需要PCIE带宽资源，建议至少Gen5考虑使用，若带宽较低，可能不如重计算

## 精度影响
无