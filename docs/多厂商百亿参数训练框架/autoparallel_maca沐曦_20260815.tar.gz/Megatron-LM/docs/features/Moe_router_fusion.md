# Moe_router_fusion

## 作用
    对moe模型router计算采用融合算子实现，进行加速

## 解决思路
    对moe模型部分，下面三组计算采用triton融合算子实现
    fused_compute_score_for_moe_aux_loss,
    fused_moe_aux_loss,
    fused_topk_with_score_function,

## 使用方法
    --moe-router-fusion

## 优点
    性能加速，在dsv3-mini模型上，e2e提升1.44%

## 缺点


## 精度影响
无