# flash-fusion算子加速

## 作用
在megatron基础上增加flash-fusion算子库的支持，加速训练

## 使用方法

--use-flash-fusion

## 优点
提速

## 缺点
无

## 精度影响
不满足严格每个iter按照1%loss对齐，正常平均1%的loss相对误差对齐都满足

## 支持的算子或pattern
* swiglu(bias swiglu)
* repeat gqa
* gelu(bias gelu)
* bda(fused bias dropout add)
* rope(rotary position embeding)
* router fusion
* More TBD
