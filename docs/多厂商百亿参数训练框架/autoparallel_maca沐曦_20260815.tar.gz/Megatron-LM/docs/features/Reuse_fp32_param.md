# Reuse fp32 param

## 作用
https://gitee.com/ascend/MindSpeed/blob/master/docs/features/reuse-fp32-param.md
复用前反向和optimizer中的参数部分

## 使用方法

--reuse-fp32-param

--deterministic-mode   可选，打开时性能损失增大，精度损失无。

## 优点
降低显存

## 缺点
性能降低

## 精度影响
只使用--reuse-fp32-param时精度影响小，当打开--deterministic-mode时无精度影响。