# Vocab parallel embedding fusion

## 作用
对vocab parallel embedding采用融合算子进行加速

## 解决思路
**************

## 使用方法

--vocab-parallel-embedding-fusion

## 优点
加速计算，单个pp stage上的layers数越少，提升越明显。
qwen3-8B， 8 layers, tp2pp1， e2e提升1.5%+。

## 缺点
无

## 精度影响
e2e 0.01%量级