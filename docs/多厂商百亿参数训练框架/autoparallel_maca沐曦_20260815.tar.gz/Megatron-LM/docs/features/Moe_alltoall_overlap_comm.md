# Moe_alltoall_overlap_comm

## 作用
    对moe模型ep切分后的all2all通信和计算并行

## 解决思路
    Ep切分后，每个transformer layer FWD和BWD一共四个all2all。FWD的第一个all2all和shared experts的FWD计算并行。BWD的all2all分别和shared experts的BWD，grouped MLP中FC1的Wgrad计算并行，理论all2all overlap率75%

## 使用方法
    --moe-alltoall-overlap-comm
    --moe-use-legacy-grouped-gemm #仅支持legacy groupgemm，不支持Transformer Engine的group gemm
    可以与sdma联合使用，即同时打开
    --use-sdma-moe-comm
    --use-sdma-grad-comm #如果moe部分存在tp切分
    重计算的方法，moe部分支持细粒度激活函数重计算
[granular-recompute-activation-function](./Granular_recompute.md)和[moe-reduce-memory](./Moe_reduce_memory.md)

## 优点
性能提升，理论all2all overlap率75%

## 缺点
开启该功能会默认使用group gemm，所以适用于group gemm有优势的场景

## 精度影响
与非overlap比，每个iter的loss相对误差小于1%