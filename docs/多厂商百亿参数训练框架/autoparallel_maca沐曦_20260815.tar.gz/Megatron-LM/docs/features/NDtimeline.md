# NDtimeline

https://github.com/volcengine/veScale/blob/main/vescale/ndtimeline/README.md

## 作用
抓取/展示并行方式下的timeline

## 使用方法

--NDtimeline    开启ndtimeline

--NDtimeline-merge   合并多个node的profile

--NDtimeline-merge-output  ndtimeline_trace_merge.json

## 优点
展现一个多机多卡的overview

## 缺点
不够精细，影响性能（很小）

## 精度影响
无