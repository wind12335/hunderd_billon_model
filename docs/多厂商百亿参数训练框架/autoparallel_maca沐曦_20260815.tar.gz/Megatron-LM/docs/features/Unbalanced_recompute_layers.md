# Unbalanced Recompute Num Layers

## 作用
通过不均匀重计算，降低显存占用比较高的stage的显存

## 使用方法

通过recompute-num-layers-list参数指定一串数字。

--recompute-num-layers-list个数等于${PP}，即PP大小。

--recompute-num-layers-list中每个数字表示每个pp stage需要重计算的layers数目。

--recompute-num-layers-list中数字边界不做检查，如果重计算层数大于等于了当前pp的层数，则表示当前pp stages所有层数都需要重计算。

recompute-num-layers-list需要设置了“recompute-granularity full和recompute-method block”才生效。设置了recompute-num-layers-list后，recompute-num-layers的设置自动失效。

## 优点
降低显存占用比较高的stage的显存

## 缺点
增加了显存占用比较高的stage的计算量

## 精度影响
无