# TransformerEngine flash attn backend

## 作用
    Transformer engine backend使用flash attn，指定flash attn的实现方式，有两种选择，
    默认采用cuda实现，或者采用asm实现，
    
    * 推荐在sequence packing场景使用，非sequence packing场景，可以直接使用--use-qkv-flash-attn

## 使用方法
--te-flash-backend cuda #choice=[cuda, asm]

设置为asm后，会在TEDotProductAttention初始化的时候，加上如下两个环境变量，

export MHA_USE_BLAS=ON #flash attn采用汇编算法，性能相关

export MHA_BWD_NO_ATOMIC_F64=1 #关闭flash attn汇编高精度算法，性能相关

## 优点
asm 性能提升，3~5%

## 缺点
不支持非sequence packing下，含有cp切分的场景

## 精度影响
无