# empty transformer layers
## use case 1
    当模型layers数，除以pp切分后为质数，怎么开启vpp功能？比如模型共15层layers，pp=3，每个pp stage 5个layer。此时如果gbs较小，无法正常开启vpp功能。
    因为，num-layers-per-vpp-stage不支持为1，当设置为5的时候，失去设置意义。

## 解决方案与使用方法 1
    a. pp bubble rate不太大，可以通过--enable-zero-bubble减少bubble
    b. pp bubble rate较大，用empty transformer layers解决
        --num-layers 18             #15层增加到18层，每个pp stage增加1 layer
        --empty-layers 0,6,12       #依次插入第0层，第6层，第12层（层数从0开始计数）
        --num-layers-per-virtual-pipeline-stage 2   #此时每个pp stage有6个layers, num_layers_per_vpp_stage可以设置为2或者3（6的约数）

## use case 2
    当模型层数为奇数，如deepseek v3有61 层，此时我们可以通过pipline_num_layers_list设置不均匀pp切分的方法，把模型跑起来。如果需要减小pp bubble rate, 
    无法使用vpp:
        1. 不均匀切分中存在质数层
        2. 不同pp stage通过vpp切分后，无法保证每个pp stage的vpp stages相等

## 解决方案与使用方法 2
    a. pp bubble rate不太大，可以通过--enable-zero-bubble减少bubble
    b. 用empty transformer layers解决，假设pp=8
    --num-layers 64                 #61层增加到64层
    --empty-layers 0,1,62,63        #依次插入第0层，第1层，第62层，第63层
    --num-layers-per-virtual-pipeline-stage 2   #此时每个pp stage有8个layers, num_layers_per_vpp_stage可以设置为2或者4

## 优点
解决vpp的使用限制，提高效率

## 缺点
无

## 精度影响
理论无
