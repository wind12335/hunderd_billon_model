# Zero bubble

## 参考
https://github.com/sail-sg/zero-bubble-pipeline-parallelism

## ZBH1

### 作用
减小pp中bubble时间， 将理论bubble率降低为1/3，且不增大显存。适用于gbs较小，bubble较大，且显存紧张的场景。

### 使用方法
--enable-zero-bubble 

### 优点
将理论bubble率降低为1/3，且不增大第一个stage的显存（理论上第一个stage的显存占用最大，因此不增加峰值显存）

### 缺点
无，如果显存充足推荐使用vpp

### 精度影响
无

## ZBV

### 作用
V型调度，减小pp中bubble时间，将理论bubble size减小为(p-1)*TF，理论不增大显存。适用于gbs较小，bubble较大的场景。

### 使用方法
--zero-bubble-v-schedule

zbv auto scheduling（可选）：
- --zero-bubble-pipeline-timers-start-iter: auto zbv开始计时iter

- --zero-bubble-pipeline-timers-end-iter: auto zbv停止计时iter

### 优点
减少bubble，理论不增大第一个stage的显存（理论上第一个stage的显存占用最大，因此不增加峰值显存）

### 缺点
同VPP，通信量翻倍，实际由于embedding和output layer都在first stage，因此显存占用增加，
同时在vocab size较大情况下，output layer计算量较大，计算不均衡导致其他stage被first stage阻塞，产生较多bubble。

可以结合--empty-layers特性实现减少first stage实际layer数均衡计算，减少bubble
在qwen3模型双机实验：默认zbv性能为803tgs，peak memory 48.1G，使用--empty-layers后性能为928tgs，peak memory 40.5G

### 精度影响
无