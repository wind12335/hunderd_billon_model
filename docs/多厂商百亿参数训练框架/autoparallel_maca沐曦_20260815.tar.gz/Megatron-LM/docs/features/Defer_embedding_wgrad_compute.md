# Defer_embedding_wgrad_compute

## 功能概述
当启用 defer_embedding_wgrad_compute 时，Megatron-LM 会将词嵌入层（vocabulary projection linear layer）
的权重梯度计算推迟到流水线（pipeline）冲刷（flush）阶段，从而借助流水线通信的空闲期来隐藏这部分计算的延迟，提升整体训练吞吐量 

## 使用条件
仅在启用了 流水线并行（pipeline_model_parallel_size > 1）且使用 梯度累积融合（gradient_accumulation_fusion=True）时有效。

## 参数说明
--defer-embedding-wgrad-compute：命令行选项，开启推迟词嵌入权重梯度计算功能。
--wgrad-deferral-limit <N>：设置在一次全局批次内最多可延迟多少个微批（micro-batch）的梯度计算。默认值 0 表示延迟所有微批的嵌入梯度计算。

## 实现机制
### 前向过程中缓存激活：
在最后一层词嵌入（ColumnParallelLinear）的 forward 中，如果 defer_embedding_wgrad_compute=True 且已缓存的激活数未超出 wgrad_deferral_limit，
则将分区后的输入张量追加到 embedding_activation_buffer 中，而不立即触发后续的 GEMM 计算。

### 反向过程中推迟计算
真正的权重梯度计算在 LinearWithGradAccumulationAndAsyncCommunication.apply 的反向执行中，并依赖于事先缓存的 embedding_activation_buffer 
和 grad_output_buffer。这些缓冲区在流水线冲刷时统一触发 GEMM，避免了在主计算路径上的额外阻塞。

## 优势与权衡
隐藏通信延迟：借助推迟计算，可与流水线阶段的通信并行执行嵌入梯度 GEMM，从而减少 GPU 空闲等待，提高吞吐。
微批级别可控：通过 wgrad_deferral_limit 精细调节延迟深度，灵活平衡延迟缓冲开销与性能增益。
采用20Layers llama2-70B， gbs64, tp2pp4，开启功能后，性能提升~1%。

