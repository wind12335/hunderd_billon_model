# Tp overlap计算通信融合算子

## 问题
计算通信并行场景，存在计算算子和通信算子资源竞争问题

## 作用
将gemm和通信融合到一起，减少资源竞争

## 使用方法

### 打开tp overlap功能，并使用计算通信融合算子
    --tp-comm-overlap
### tp overlap中的bulk rs和bulk ag使用sdma功能
    --use-sdma-grad-comm
## 优点
提升性能，通信计算资源竞争越明显（计算kernel被拖慢越厉害），提升效果越好

## 缺点
1. reduce算法和rs ring算法不同，无法保证loss完全一致

## 精度影响
小