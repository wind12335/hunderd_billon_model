# Moe_adaptive_recompute

## 问题
    moe模型中因为专家切分，导致每个ep rank上专家分到的tokens数不同。在训练初期，这种不均衡性会导致tokens较多的ep rank OOM。

## 解决思路
    通过提前感知每个ep rank的tokens总数，当存在某个ep rank的tokens总数超过一定阈值时，开启重计算。当不超过阈值时，关闭重计算。避免OOM的同时可以提高性能。
    当dispatcher是all2all dispatcher或all2all_seq dispatcher时，开启--moe-layer-recompute
    当dispatcher是all2all overlap dispatcher时，开启--moe-reduce-memory的level1全layers重计算

## 使用方法
    --moe-adaptive-recompute
    --moe-adaptive-recompute-scale 2.0, default = 2.0

## 优点
性能提升，避免OOM

## 缺点
不支持all gather dispatcher, 即--moe-token-dispatcher-type allgather

## 精度影响
无