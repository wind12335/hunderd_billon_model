# Use sdma comm计算通信并行通信优化

## 问题
计算通信并行场景，存在计算算子和通信算子资源竞争问题

## 作用
节点内通信算子采用dma engine，节点间通信采用cpu,减少对计算资源的竞争

## 使用方法

### 所有计算通信并行处通信采用sdma
    --use-sdma-comm，
    会使所有切分下的overlap通信采用sdma，dp overlap场景需要打开--overlap-grad-reduce和--overlap-param-gather并合理调节--ddp-bucket-size作为前提

### 单独打开grad的计算通信并行sdma
    --use-sdma-grad-comm，
    在sequence parallel打开场景，dgrad会与all gather(sdma)并行，wgrad会与reduce-scatter（sdma）并行
    在非sequence parallel场景，dgrad会与all reduce(sdma)并行

### 单独打开dp的计算通信并行sdma
    --use-sdma-dp-comm
    在--use-distributed-optimizer场景下，需要打开--overlap-grad-reduce和--overlap-param-gather
    在非--use-distributed-optimizer场景下，需要打开--overlap-grad-reduce

    dp overlap下的细节控制：
    1. --use-sdma-dp-ag-comm: 控制--use-distributed-optimizer场景下的--overlap-param-gather
    2. --use-sdma-dp-rs-comm: 控制--use-distributed-optimizer场景下的--overlap-grad-reduce
    3. --use-sdma-dp-ar-comm: 控制非--use-distributed-optimizer场景下的--overlap-grad-reduce

    打开sdma后，ddp-bucket-size可能会有变化，需要重新调节

### 单独打开pp的计算通信并行sdma
    --use-sdma-pp-comm
    pp计算通信并行需要打开--num-layers-per-virtual-pipeline-stage

### 单独打开moe的计算通信并行sdma
    --use-sdma-moe-comm 
    可以与Moe_alltoall_overlap_comm结合使用，即同时打开
    --moe-permute-use-dense
    --moe-alltoall-overlap-comm
    对moe模型Moe_layer部分，选择部分计算通信竞争较大的通信算子走sdma，如果存在tp切分，推荐同时打开--use-sdma-grad-comm

## 优点
提升性能，通信计算资源竞争越明显（计算kernel被拖慢越厉害），提升效果越好

## 缺点
1. sdma通信的顺序和ring算法不同，无法保证loss完全一致
2. 节点间通信场景，当前优化还不完备，可能性能不如mccl使用xcore实现的算子

## 精度影响
小