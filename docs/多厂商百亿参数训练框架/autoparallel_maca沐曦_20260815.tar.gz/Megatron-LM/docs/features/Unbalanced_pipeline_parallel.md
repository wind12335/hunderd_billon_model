# Unbalanced PP

## 作用
通过不均匀切分，降低第一个stage的显存和计算量，降低最后一个stage的计算量

## 使用方法

通过pipline-num-layers-list参数指定一串数字。

--pipline-num-layers-list个数等于${PP}，即PP大小。

--pipline-num-layers-list总和等于模型的layers数量，比如7b是32。

pipline-num-layers-list中每个数字表示每个pp stage分到的layers数目。如果不使用pipline-num-layers-list参数，框架默认对pp的layers均匀切分。

## 优点
降低第一个stage的显存和计算量，降低最后一个stage的计算量

## 缺点
增加了中间stage的计算量

## 精度影响
无