#!/bin/bash
set -e
CURRENT_DIR="$( cd "$( dirname "$0" )" && pwd )"
MEGATRON_PATH=$( dirname $( dirname ${CURRENT_DIR}))


export MACA_PATH=/opt/maca
export MACA_CLANG_PATH=${MACA_PATH}/mxgpu_llvm/bin
export MACA_CLANG=${MACA_PATH}/mxgpu_llvm
export DEVINFO_ROOT=${MACA_PATH}
export CUCC_PATH=${MACA_PATH}/tools/cu-bridge
export CUDA_PATH=${CUCC_PATH}
export PATH=${CUCC_PATH}:${MACA_PATH}/bin:${MACA_CLANG}/bin:${PATH}
export LD_LIBRARY_PATH=${MACA_PATH}/lib:${MACA_PATH}/mxgpu_llvm/lib:${LD_LIBRARY_PATH}
export CUDA_DEVICE_MAX_CONNECTIONS=1
export MACA_SMALL_PAGESIZE_ENABLE=1
export SET_DEVICE_NUMA_PREFERRED=1
export MAX_JOBS=20
export PYTORCH_ENABLE_SAME_RAND_A100=1

export NCCL_ALGO=Ring
export NVTE_ALLOW_NONDETERMINISTIC_ALGO=0
export CUBLAS_WORKSPACE_CONFIG=:4096:8

export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
MASTER_ADDR=localhost
MASTER_PORT=22233
NNODES=1
NODE_RANK=0
GPUS_PER_NODE=8

DISTRIBUTED_ARGS="--nproc_per_node $GPUS_PER_NODE --nnodes $NNODES --node_rank $NODE_RANK --master_addr $MASTER_ADDR --master_port $MASTER_PORT"

### BASE CONFIG ###
MODEL_SIZE=mini
BATCH_SIZE=1
GLOBAL_BATCH_SIZE=32
LR=1e-5
MIN_LR=1e-6
SEQ_LEN=4096
TP=2
PP=2
CP=1
EP=2

SAVE_INTERVAL=10000000
TRAIN_TOKENS=10000000
WARMUP_TOKENS=1000

DATASET_PATH=/software/xxxx/deepseek-v3/deepseek_v3_data/mmap_deepseekv2_datasets_text_document
TOKENIZER_MODEL=/software/xxxx/deepseek-v3/DeepSeek-V3/
OUTPUT_BASEPATH=./


if [ $MODEL_SIZE = A37B ]; then
    HIDDEN_SIZE=7168
    NUM_ATTN_HEADS=128
    NUM_LAYERS=3
    FIRST_K_DENSE_REPALCE=1
    INTERMEDIATE_SIZE=18432
    MOE_INTERMEDIATE_SIZE=2048
    MAX_POSITION_EMBEDDINGS=163840
    MOE_LAYER_FREQ_REPEAT=1
    Q_LORA_RANK=1536
    KV_LORA_RANK=512
    QK_NOPE_HEAD_DIM=128
    QK_ROPE_HEAD_DIM=64
    V_HEAD_DIM=128
    ROPE_THETA=10000
    SCALE_FACTOR=40
    NUM_EXPERTS=4
    ROUTER_TOPK=2
    NUM_SHARED_EXPERTS=1
    RMS_NORM_EPS=1e-6
    N_GROUP=8
    TOPK_GROUP=4
    ROUTED_SCALING_FACTOR=2.5
    NUM_NEXTN_PREDICT_LAYERS=1
    VOCAB_SIZE=129280
    MSCALE=1.0
    MSCALE_ALL_DIM=1.0


    moe_options=" \
        --moe-ffn-hidden-size ${MOE_INTERMEDIATE_SIZE} \
        --moe-layer-freq \"([0]*${FIRST_K_DENSE_REPALCE}+[1]*$((NUM_LAYERS-FIRST_K_DENSE_REPALCE)))*${MOE_LAYER_FREQ_REPEAT}\"
        --moe-shared-expert-intermediate-size  $((NUM_SHARED_EXPERTS*MOE_INTERMEDIATE_SIZE)) \
        --moe-router-load-balancing-type seq_aux_loss \
        --moe-router-score-function sigmoid \
        --moe-router-topk ${ROUTER_TOPK} \
        --num-experts ${NUM_EXPERTS} \
        --moe-router-enable-expert-bias
        --moe-aux-loss-coeff 1e-3 \
        --moe-token-dispatcher-type alltoall \
        --expert-model-parallel-size ${EP} \
        --q-lora-rank ${Q_LORA_RANK} \
        --kv-lora-rank ${KV_LORA_RANK} \
        --qk-head-dim ${QK_NOPE_HEAD_DIM} \
        --qk-pos-emb-head-dim ${QK_ROPE_HEAD_DIM} \
        --v-head-dim ${V_HEAD_DIM} \
        --moe-router-topk-scaling-factor ${ROUTED_SCALING_FACTOR} \
        --mscale ${MSCALE} \
        --mscale-all-dim ${MSCALE_ALL_DIM} \
        --mtp-num-layers ${NUM_NEXTN_PREDICT_LAYERS} \
        --moe-router-num-groups ${N_GROUP} \
        --moe-router-group-topk ${TOPK_GROUP} \
        "

elif [ $MODEL_SIZE = mini ]; then
    HIDDEN_SIZE=2048
    NUM_ATTN_HEADS=16
    NUM_LAYERS=8
    FIRST_K_DENSE_REPALCE=1
    INTERMEDIATE_SIZE=10944
    MOE_INTERMEDIATE_SIZE=1408
    MAX_POSITION_EMBEDDINGS=163840
    MOE_LAYER_FREQ_REPEAT=1
    Q_LORA_RANK=1536
    KV_LORA_RANK=512
    QK_NOPE_HEAD_DIM=128
    QK_ROPE_HEAD_DIM=64
    V_HEAD_DIM=128
    ROPE_THETA=10000
    SCALE_FACTOR=40
    NUM_EXPERTS=64
    ROUTER_TOPK=6
    NUM_SHARED_EXPERTS=2
    RMS_NORM_EPS=1e-6
    N_GROUP=8
    TOPK_GROUP=4
    ROUTED_SCALING_FACTOR=1
    NUM_NEXTN_PREDICT_LAYERS=1
    VOCAB_SIZE=102400
    MSCALE=0.707
    MSCALE_ALL_DIM=1.0

    moe_options=" \
        --moe-ffn-hidden-size ${MOE_INTERMEDIATE_SIZE} \
        --moe-layer-freq \"([0]*${FIRST_K_DENSE_REPALCE}+[1]*$((NUM_LAYERS-FIRST_K_DENSE_REPALCE)))*${MOE_LAYER_FREQ_REPEAT}\"
        --moe-shared-expert-intermediate-size  $((NUM_SHARED_EXPERTS*MOE_INTERMEDIATE_SIZE)) \
        --moe-router-load-balancing-type seq_aux_loss \
        --moe-router-score-function sigmoid \
        --moe-router-topk ${ROUTER_TOPK} \
        --num-experts ${NUM_EXPERTS} \
        --moe-router-enable-expert-bias
        --moe-aux-loss-coeff 1e-3 \
        --moe-token-dispatcher-type alltoall \
        --expert-model-parallel-size ${EP} \
        --q-lora-rank ${Q_LORA_RANK} \
        --kv-lora-rank ${KV_LORA_RANK} \
        --qk-head-dim ${QK_NOPE_HEAD_DIM} \
        --qk-pos-emb-head-dim ${QK_ROPE_HEAD_DIM} \
        --v-head-dim ${V_HEAD_DIM} \
        --moe-router-num-groups ${N_GROUP} \
        --moe-router-group-topk ${TOPK_GROUP} \
        --moe-router-topk-scaling-factor ${ROUTED_SCALING_FACTOR} \
        --mscale ${MSCALE} \
        --mscale-all-dim ${MSCALE_ALL_DIM} \
        --mtp-num-layers ${NUM_NEXTN_PREDICT_LAYERS}
        "
fi

TRAIN_ITERS=$(( ${TRAIN_TOKENS} / ${GLOBAL_BATCH_SIZE} / ${SEQ_LEN} ))
LR_WARMUP_ITERS=$(( ${WARMUP_TOKENS}  / ${GLOBAL_BATCH_SIZE} / ${SEQ_LEN} ))
LR_DECAY_ITERS=$(( ${TRAIN_TOKENS} /  ${GLOBAL_BATCH_SIZE} / ${SEQ_LEN} ))
PREFIX="pretrain-mcore-deepseek-v3"

##### Prepare logdirs #######
NAME="${PREFIX}-tp-${TP}-pp-${PP}-ep-${EP}-gbs-${GLOBAL_BATCH_SIZE}-layers-${NUM_LAYERS}"
mkdir -p "${OUTPUT_BASEPATH}/checkpoint/"
mkdir -p "${OUTPUT_BASEPATH}/log/"
current_time=$(date "+%Y.%m.%d-%H.%M")
TENSORBOARD_DIR="${OUTPUT_BASEPATH}/tensorboard/${NAME}_${current_time}"
mkdir -p ${TENSORBOARD_DIR}
SAVED_PRETRAIN_CHECKPOINT_PATH="${OUTPUT_BASEPATH}/checkpoint/${NAME}"
mkdir -p ${SAVED_PRETRAIN_CHECKPOINT_PATH}

LOG_PATH_NAME="${OUTPUT_BASEPATH}/log/${NAME}_${current_time}"
mkdir -p ${LOG_PATH_NAME}
LOG_PATH=${OUTPUT_BASEPATH}/${LOG_PATH_NAME}/node_${NODE_RANK}.log

megatron_options="  \
        --data-path ${DATASET_PATH} \
        --tokenizer-model ${TOKENIZER_MODEL} \
        --split 99,1,0 \
        --lr ${LR} \
        --min-lr ${MIN_LR} \
        --lr-decay-style cosine \
        --weight-decay 0.1 \
        --adam-beta1 0.9 \
        --adam-beta2 0.95 \
        --clip-grad 1.0 \
        --init-method-std 0.02 \
        --attention-dropout 0.0 \
        --hidden-dropout 0.0 \
        --lr-decay-iters ${LR_DECAY_ITERS} \
        --lr-warmup-iters ${LR_WARMUP_ITERS} \
        --train-iters ${TRAIN_ITERS} \
        --micro-batch-size ${BATCH_SIZE} \
        --global-batch-size ${GLOBAL_BATCH_SIZE} \
        --num-layers ${NUM_LAYERS} \
        --hidden-size ${HIDDEN_SIZE} \
        --num-attention-heads ${NUM_ATTN_HEADS} \
        --ffn-hidden-size ${INTERMEDIATE_SIZE} \
        --seq-length ${SEQ_LEN} \
        --max-position-embeddings ${MAX_POSITION_EMBEDDINGS} \
        --log-interval 1 \
        --log-throughput \
        --eval-interval 10000 \
        --eval-iters 10 \
        --save-interval ${SAVE_INTERVAL} \
        --tensorboard-queue-size 1 \
        --tensorboard-dir ${TENSORBOARD_DIR} \
        --log-timers-to-tensorboard \
        --log-validation-ppl-to-tensorboard \
        --tensor-model-parallel-size ${TP} \
        --pipeline-model-parallel-size ${PP} \
        --context-parallel-size ${CP} \
        --no-load-optim \
        --no-load-rng \
        --num-workers 8 \
        --tokenizer-type HuggingFaceTokenizer \
        --vocab-size ${VOCAB_SIZE} \
        --swiglu \
        --normalization RMSNorm \
        --norm-epsilon ${RMS_NORM_EPS} \
        --use-rotary-position-embeddings \
        --position-embedding-type rope \
        --untie-embeddings-and-output-weights \
        --disable-bias-linear \
        --rotary-base ${ROPE_THETA} \
        --rotary-scaling-factor ${SCALE_FACTOR} \
        --rotary-seq-len-interpolation-factor 1 \
        --no-save-optim \
        --kv-channels ${V_HEAD_DIM} \
        --qk-layernorm \
        --bf16 \
        --use-distributed-optimizer \
        --transformer-impl transformer_engine \
        --sequence-parallel \
        --multi-latent-attention \
        --no-rope-fusion \
        --device-tflops 240 \
        --yarn-rope-fusion \
        --accumulate-bf16 \
        --deterministic-mode \
        --attention-backend flash \
        --use-flash-attn \
        --moe-permute-fusion \
        "
        # --moe-use-legacy-grouped-gemm \

        # --moe-grouped-gemm-3D

        # --moe-batched-gemm \
        # --moe-pad-expert-input-to-capacity \
        # --moe-expert-capacity-factor 1.0 \

run_cmd="torchrun $DISTRIBUTED_ARGS ../pretrain_gpt.py ${megatron_options} ${moe_options}"

echo ${run_cmd}
eval ${run_cmd} 2>&1 | tee ${LOG_PATH}
set +x
