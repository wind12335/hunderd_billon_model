import functools
import logging
import os
import queue
from contextlib import contextmanager

try:

    from transformer_engine.pytorch.zbpp import WeightGradStore

    HAVE_TE = True

except ImportError as e:
    print(f'can not import WeightGradStore from TE:{e}')
    HAVE_TE = False


class LocalWeightGradStore:

    should_split_bw = False
    cache = []
    weight_grad_queue = None  # lazy init

    @classmethod
    def lazy_init(cls):
        if cls.weight_grad_queue is not None:
            return
        num_chunks = 2
        
        # chunk id => seq id => Queue
        cls.weight_grad_queue = [[queue.Queue() for _ in range(1)] for _ in range(num_chunks)]

   
    @classmethod
    def split_bw(cls):
        # if not cls.is_supported():
        #     return False
        return cls.should_split_bw

    @classmethod
    def enable_split_bw(cls):
        cls.should_split_bw = True

    @classmethod
    def disable_split_bw(cls):
        cls.should_split_bw = False

    @classmethod
    @contextmanager
    def set_split_bw(cls, enabled: bool):
        prev = cls.should_split_bw
        cls.should_split_bw = enabled
        try:
            yield
        finally:
            cls.should_split_bw = prev

    @classmethod
    def put(cls, pre_func, func):
        assert cls.split_bw()
        # func(*pre_func(async_op=False))
        cls.cache.append((pre_func, func))
        return

    @classmethod
    def queue_size(cls, chunk=0, seq_split_idx=0):
        cls.lazy_init()
        return WeightGradStore.weight_grad_queue[chunk][seq_split_idx].qsize()

    @classmethod
    def flush(cls, chunk=0, seq_split_idx=0):
        cls.lazy_init()
        # Or W later will consume empty computation and leak the non-empty computation.
        if not cls.split_bw():
            assert len(cls.cache) == 0
            return
        cls.weight_grad_queue[chunk][seq_split_idx].put(cls.cache)
        cls.cache = []

    @classmethod
    def pop(cls, chunk=0, seq_split_idx=0):
        cls.lazy_init()
        if cls.weight_grad_queue[chunk][seq_split_idx].qsize() > 0:
            stored_grads = cls.weight_grad_queue[chunk][seq_split_idx].get()
            for pre_func, func in stored_grads:
                func(*pre_func(async_op=False))
        else:
            #rank = parallel_state.get_pipeline_model_parallel_rank()
            raise Exception(f"Pop empty queue.")

    @classmethod
    def assert_empty(cls):
        assert len(cls.cache) == 0, f"cache is not empty. rank "
        if cls.weight_grad_queue is None:
            return
        for chunk, chunk_q in enumerate(cls.weight_grad_queue):
            for seq, seq_q in enumerate(chunk_q):
                assert seq_q.empty(), f"Queue is not empty chunk {chunk} seq {seq}. len {seq_q.qsize()}"

    @classmethod
    def clear(cls, model=None, chunk=0, seq_split_idx=0):
        cls.lazy_init()
        weight_grad_tasks = []
        while cls.weight_grad_queue[chunk][seq_split_idx].qsize() > 0:
            stored_grads = cls.weight_grad_queue[chunk][seq_split_idx].get()
            if len(weight_grad_tasks) == 0:
                for _ in stored_grads:
                    weight_grad_tasks.append([])
            else:
                assert len(weight_grad_tasks) == len(stored_grads)
            for i, task in enumerate(stored_grads):
                weight_grad_tasks[i].append(task)
        # timers = get_timers()
        # weight_params = []
        # handles = []
        # if get_args().overlap_grad_reduce:
        #     handles += model.async_reduce_grad()

        # config = get_model_config(model)
        # # Do async all-reduce for embedding grads firstly, so that the rank 0 won't
        # # be blocked
        # embedding_handles = _allreduce_embedding_grads([model], config, async_op=True)
        # handles += embedding_handles

        for i in range(len(weight_grad_tasks)):
            tasks = weight_grad_tasks[i]
            #param = None
            for j in range(len(tasks)):
                pre_func, func = tasks[j]
                # if param is None:
                #     param = weight
                # assert param.storage().data_ptr() == weight.storage().data_ptr()
                func(*pre_func(async_op=False))
                tasks[j] = None  # release memory
            # weight_params.append(param)
            # if get_args().overlap_grad_reduce:
            #     # All-reduce param grad here
            #     handles += model.async_reduce_grad(param)
            weight_grad_tasks[i] = None  # release memory

        # timers('wait_all_reduce', log_level=1).start(barrier=False)
        # for handle in handles:
        #     if handle is not None:
        #         handle.wait()
        # timers('wait_all_reduce').stop()
if not HAVE_TE:
    WeightGradStore = LocalWeightGradStore