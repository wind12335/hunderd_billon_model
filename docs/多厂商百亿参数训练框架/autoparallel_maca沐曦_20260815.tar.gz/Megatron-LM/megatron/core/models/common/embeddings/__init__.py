# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.

from .rope_utils import apply_rotary_pos_emb
from .rotary_pos_embedding import MultimodalRotaryEmbedding, RotaryEmbedding
from .yarn_rotary_pos_embedding import YarnRotaryEmbedding, _yarn_get_mscale
from .yarn_rotary_pos_embedding_pai import YarnRotaryEmbeddingFuse, yarn_get_mscale, apply_rotary_pos_emb_fuse