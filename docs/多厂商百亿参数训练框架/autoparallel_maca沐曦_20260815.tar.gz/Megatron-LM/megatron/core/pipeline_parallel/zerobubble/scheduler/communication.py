import dataclasses
import functools
from typing import List, Tuple

from megatron.core.pipeline_parallel.zerobubble.scheduler.graph import GraphConfig, F, B, BW, FuncType, ScheduledNode, CommDirection


@dataclasses.dataclass(eq=True, frozen=True)
class CommPair:
    send_node: ScheduledNode
    recv_node: ScheduledNode
    recv_deadline: ScheduledNode

    def __post_init__(self) -> None:
        assert self.send_node
        assert self.recv_node
        assert self.recv_deadline

def add_communication_nodes_without_sorting(
    config: GraphConfig,
    local_order: List[List[ScheduledNode]],
) -> List[List[ScheduledNode]]:
    local_order, comm_pairs = insert_send_nodes(config, local_order)
    local_order = insert_recv_nodes(config, local_order, comm_pairs)
    return local_order


def insert_send_nodes(
    config: GraphConfig,
    local_order: List[List[ScheduledNode]]
) -> Tuple[List[List[ScheduledNode]], List[CommPair]]:
    assert len(local_order) == config.n_stages
    node_map = {n.get_key(): n for n in sum(local_order, [])}
    comm_pair_id = 0
    new_local_order = [[n for n in stage_nodes] for stage_nodes in local_order]

    comm_pairs = []

    for stage in range(config.n_stages):
        for node in local_order[stage]:
            assert stage == node.stage, f"Invalid node stage {stage} {node}"
            if node.type not in (F, B, BW):  # no communication for W
                continue
            cat_str = "FORWARD" if node.type == F else "BACKWARD"

            def create_communicate_node(send_recv, compute_node, comm_peer_stage, t, comm_direction, comm_pair_id):
                # noinspection PyTypeChecker
                return ScheduledNode(
                    type=FuncType(send_recv + cat_str),
                    chunk=compute_node.chunk,
                    stage=compute_node.stage,
                    microbatch=node.microbatch,
                    seq_split_idx=node.seq_split_idx,
                    layer_group_idx=compute_node.layer_group_idx,
                    start_time=t,
                    completion_time=t,  # TODO: consider comm cost in completion time
                    comm_direction=comm_direction,
                    comm_peer_stage=comm_peer_stage,
                    comm_pair_id=comm_pair_id,
                )

            if node.recv_peer_stage is None or node.recv_peer_stage == node.stage:
                pass
            else:
                if node.recv_peer_stage + 1 == node.stage or (node.stage == 0 and node.recv_peer_stage == config.n_stages - 1):
                    # recv from prev
                    send_direction = CommDirection.NEXT
                    recv_direction = CommDirection.PREV
                else:
                    # recv from next
                    assert node.recv_peer_stage == node.stage + 1 or \
                           (node.recv_peer_stage == 0 and node.stage == config.n_stages - 1), \
                        f"Invalid send-recv stages {node.recv_peer_stage} {node.stage}"
                    send_direction = CommDirection.PREV
                    recv_direction = CommDirection.NEXT
                peer = node_map[node.get_prev_key(config.num_layer_groups())]
                assert peer.stage == node.recv_peer_stage
                send_node = create_communicate_node("SEND_", peer, stage, peer.completion_time, send_direction, comm_pair_id)
                recv_node = create_communicate_node("RECV_", node, peer.stage, peer.completion_time, recv_direction, comm_pair_id)
                comm_pairs.append(CommPair(send_node, recv_node, recv_deadline=node))
                comm_pair_id += 1

                send_stage_nodes = new_local_order[send_node.stage]
                send_compute_pos = next((i for i, n in enumerate(send_stage_nodes) if n.get_key() == peer.get_key()))
                insert_pos = send_compute_pos + 1
                # Some offload nodes may locate after the compute node,
                # but it's start_time is the same of the compute node,
                # which is less than the start_time of the SEND here.
                insert_pos = next((
                    i + insert_pos for i, n in enumerate(send_stage_nodes[insert_pos:])
                        if n.start_time >= send_node.start_time
                ), len(send_stage_nodes))
                send_stage_nodes.insert(insert_pos, send_node)

    return new_local_order, comm_pairs


def insert_recv_nodes(
        config: GraphConfig,
        local_order: List[List[ScheduledNode]],
        comm_pairs: List[CommPair],
    ) -> List[List[ScheduledNode]]:
    from .passes import viz_node

    send_index_map = {
        p.send_node.get_key(): local_order[p.send_node.stage].index(p.send_node) for p in comm_pairs
    }

    # Add index to make sure the order is consistent with the order in each stage.
    def cmp_pair(a: CommPair, b: CommPair):
        sa, sb = a.send_node, b.send_node
        if sa.stage == sb.stage:
            return send_index_map[sa.get_key()] - send_index_map[sb.get_key()]
        elif sa.start_time == sb.start_time:
            # Let SEND_POST_VALIDATION go first
            a_type_rank = int(sa.type != FuncType.SEND_POST_VALIDATION)
            b_type_rank = int(sb.type != FuncType.SEND_POST_VALIDATION)
            return a_type_rank - b_type_rank
        return sa.start_time - sb.start_time

    # This sorting preserves the original order if start_time are the same,
    # which preserve the same behaviour of previous time-sorting based implementation for non-zb schedules.
    comm_pairs.sort(key=functools.cmp_to_key(cmp_pair))
    start_indices = [0 for _ in local_order]
    new_local_order = local_order

    for pair in comm_pairs:
        send_node = pair.send_node
        recv_node = pair.recv_node
        recv_deadline = pair.recv_deadline

        send_stage_nodes = new_local_order[send_node.stage]
        start = start_indices[send_node.stage]
        send_pos = next((i + start for i, n in enumerate(send_stage_nodes[start:]) if n.get_key() == send_node.get_key()))
        assert send_pos >= start
        start_indices[send_node.stage] = send_pos + 1

        # Pop the communication from offload to avoid conflict
        while True:
            idx, offload_barrier = next((
                (i + start, n) for i, n in enumerate(send_stage_nodes[start:send_pos])
                    if n.type.has_offload_barrier()
            ), (None, None))
            if not offload_barrier:
                break
            start = idx + 1

            peer_stage = offload_barrier.stage ^ 1
            peer_start = start_indices[peer_stage]
            peer_node_idx = None
            peer_nodes = local_order[peer_stage][peer_start:]
            for i, n in enumerate(peer_nodes):
                if n.type.is_send():
                    break
                if n.type.has_offload_barrier():
                    peer_node_idx = i + peer_start
                    break

            peer_nodes_str = ' '.join(map(viz_node, peer_nodes))
            assert peer_node_idx, \
                f"cannot find peer offload barrier. Tried to find peer of {offload_barrier} in stage {peer_stage} nodes: {peer_nodes_str}"
            start_indices[peer_stage] = peer_node_idx + 1

        recv_stage_nodes = new_local_order[recv_node.stage]
        start = start_indices[recv_node.stage]
        # There shouldn't be timespan overlap for non-communication nodes.
        recv_pos = next(
            (i + start for i, n in enumerate(recv_stage_nodes[start:])
                if (recv_node.start_time <= n.completion_time
                    or n.get_key() == recv_deadline.get_key()  # Recv should go before its consumer node.
                    or n.type.is_send() or n.type.has_offload_barrier())  # Avoid cross dependency.
             ))
        recv_stage_nodes.insert(recv_pos, recv_node)
        start_indices[recv_node.stage] = recv_pos + 1

        stage_nodes_str = ' '.join(map(viz_node, recv_stage_nodes))
        assert any(n for n in recv_stage_nodes[recv_pos+1:] if n.get_key() == recv_deadline.get_key()), \
            f"Cannot find recv consumer node after recv: stage {recv_node.stage} recv {viz_node(recv_node)} consumer {viz_node(recv_deadline)} nodes: {stage_nodes_str}"

    assert len(new_local_order) == config.n_stages
    return new_local_order
