# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.
# Copyright (c) 2025, Huawei Technologies Co., Ltd. All rights reserved.

from megatron.core import mpu
from megatron.legacy.model.module import fp32_to_float16, float16_to_fp32
from megatron.core.transformer.transformer_config import TransformerConfig
from megatron.core import parallel_state

import torch
from megatron.core.pipeline_parallel.dualpipev.dualpipev_schedules import get_dualpipe_chunk


def get_transformer_layer_offset(config: TransformerConfig):
    """Get the index offset of current pipeline stage, given the level of pipelining."""
    pipeline_rank = parallel_state.get_pipeline_model_parallel_rank()
    num_layers_per_pipeline_rank = config.num_layers // config.pipeline_model_parallel_size
    num_layers_per_pipeline_rank = num_layers_per_pipeline_rank // 2
    if config.dualpipev_first_chunk:
        offset = pipeline_rank * num_layers_per_pipeline_rank
    else:
        offset = config.num_layers - (pipeline_rank + 1) * num_layers_per_pipeline_rank
    return offset


def dualpipev_fp16forward(self, *inputs, **kwargs):
    dualpipe_first_stage = mpu.is_pipeline_first_stage() and get_dualpipe_chunk() == 0
    if dualpipe_first_stage:
        inputs = fp32_to_float16(inputs, self.float16_convertor)
    outputs = self.module(*inputs, **kwargs)
    dualpipe_last_stage = mpu.is_pipeline_first_stage() and get_dualpipe_chunk() == 1
    if dualpipe_last_stage:
        outputs = float16_to_fp32(outputs)
    return outputs


def get_num_layers_to_build(config: TransformerConfig) -> int:

    num_layers_per_pipeline_rank = (
        config.num_layers // parallel_state.get_pipeline_model_parallel_world_size()
    )

    num_layers_to_build = num_layers_per_pipeline_rank // 2

    return num_layers_to_build


