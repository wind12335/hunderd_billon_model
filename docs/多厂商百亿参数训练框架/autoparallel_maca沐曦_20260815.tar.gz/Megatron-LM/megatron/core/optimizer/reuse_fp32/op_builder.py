from abc import ABC
import os
from torch.utils.cpp_extension import load


class Reuse_fp32_OpBuilder(ABC):
    _loaded_ops = {}  # 用于缓存已加载的模块

    def __init__(self):
        self.name = 'reuse_data_ptr'

    def get_maca_path(self):
        return os.getenv('MACA_PATH')
    
    def get_code_path(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        cpp_file = 'reuse_data_ptr.cpp'
        return os.path.join(current_dir, cpp_file)

    def load(self, verbose=True):
        if self.name in __class__._loaded_ops:
            return __class__._loaded_ops[self.name]

        op_module = load(name=self.name,
                         sources=[self.get_code_path()],
                         extra_include_paths=[self.get_maca_path()],
                         extra_cflags=[
                            '-gencode', 'arch=compute_80,code=sm_80',
                        ],
                         extra_cuda_cflags=['-O2'], 
                         verbose=verbose)
        __class__._loaded_ops[self.name] = op_module

        return op_module