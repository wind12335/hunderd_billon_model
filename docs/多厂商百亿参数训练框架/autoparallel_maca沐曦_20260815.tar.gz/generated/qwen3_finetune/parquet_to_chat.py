#!/usr/bin/env python3
"""Infinity-Instruct-7M-Core parquet → Qwen3 chat 格式 jsonl。

每个样本格式化为完整对话（不含 think 块，对 Base 模型直接输出回答）：
  <|im_start|>user\n{...}<|im_end|>\n<|im_start|>assistant\n{...}<|im_end|>\n
多轮对话按顺序拼接。
"""
import glob
import json
import sys
import time

import pyarrow.parquet as pq

DATA_DIR = "/root/workspace/datasets/Infinity-Instruct-7M-Core/7M_core"
OUT = "/root/workspace/datasets/Infinity-Instruct-7M-Core/qwen3_chat.jsonl"


def fmt_conv(msgs) -> str:
    parts = []
    for m in msgs:
        role = m.get("from", "")
        text = m.get("value", "")
        if role == "system":
            parts.append(f"<|im_start|>system\n{text}<|im_end|>\n")
        elif role in ("human", "user"):
            parts.append(f"<|im_start|>user\n{text}<|im_end|>\n")
        elif role in ("gpt", "assistant"):
            parts.append(f"<|im_start|>assistant\n{text}<|im_end|>\n")
    return "".join(parts)


def main() -> None:
    files = sorted(glob.glob(f"{DATA_DIR}/*.parquet"))
    if not files:
        sys.exit(f"未找到 parquet: {DATA_DIR}/*.parquet")
    t0 = time.time()
    n = 0
    empty = 0
    with open(OUT, "w", encoding="utf-8") as f:
        for fp in files:
            table = pq.read_table(fp, columns=["conversations"])
            arr = table.column("conversations").to_pylist()
            for conv in arr:
                text = fmt_conv(conv)
                if not text.strip():
                    empty += 1
                    continue
                f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
                n += 1
            print(
                f"  {fp} 完成, 累计 {n} 行, 用时 {time.time()-t0:.1f}s",
                flush=True,
            )
    print(f"全部完成: {n} 行 -> {OUT}（空样本 {empty} 条跳过）")


if __name__ == "__main__":
    main()
