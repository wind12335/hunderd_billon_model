#!/usr/bin/env python3
"""验证 HF Qwen3 与转换后的 mcore 模型输出 logits 一致性。

用法（autoparallel 根目录）：
  python -m torch.distributed.run --nproc_per_node 1 \
      generated/qwen3_finetune/verify_hf_vs_mcore.py
"""
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "generated/qwen3_finetune"))

MODEL_DIR = "/root/workspace/model/Qwen-13B-base"

import convert_hf_qwen3_to_mcore as conv


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    from megatron.training import get_args
    from megatron.training.utils import get_ltor_masks_and_position_ids

    conv.build_megatron_args(tp=1)
    initialize_megatron(ignore_unknown_args=True)
    args = get_args()

    from pretrain_gpt import model_provider

    model = model_provider(pre_process=True, post_process=True).to(torch.bfloat16)
    model.eval()

    hf = conv.load_hf_weights(MODEL_DIR)
    model_state = model.state_dict()
    local_dict = conv.map_and_shard(hf, model_state, tp=1, rank=0)
    model.load_state_dict(local_dict, strict=False)
    print("[mcore] 权重载入完成")

    # 固定输入序列（取一段真实 token id）
    torch.manual_seed(0)
    seq_len = 32
    input_ids = torch.randint(0, 1000, (1, seq_len)).cuda()

    with torch.no_grad():
        attention_mask, position_ids, _ = get_ltor_masks_and_position_ids(
            input_ids,
            args.vocab_size,
            args.reset_position_ids,
            args.reset_attention_mask,
            args.eod_mask_loss,
        )
        mcore_logits = model(
            input_ids,
            position_ids,
            attention_mask,
            runtime_gather_output=True,
        )
        # mcore logits 形状 [b, s, padded_vocab]
        mcore_logits = mcore_logits.float()

    print("[mcore] 前向完成, logits shape:", tuple(mcore_logits.shape))

    # HF 参考（CPU）
    from transformers import AutoModelForCausalLM, AutoConfig

    print("[hf] 加载 HF 模型到 CPU ...")
    hf_model = AutoModelForCausalLM.from_pretrained(
        MODEL_DIR,
        torch_dtype=torch.bfloat16,
        attn_implementation="eager",
        low_cpu_mem_usage=False,
    )
    hf_model.eval()
    hf_ids = input_ids.cpu()
    with torch.no_grad():
        hf_logits = hf_model(hf_ids).logits.float()  # [b, s, 151936]

    print("[hf] 前向完成, logits shape:", tuple(hf_logits.shape))

    m = mcore_logits[:, :, :151936].cpu()
    h = hf_logits
    assert m.shape == h.shape, f"shape mismatch {m.shape} vs {h.shape}"

    diff = (m - h).abs()
    max_diff = diff.max().item()
    mean_diff = diff.mean().item()
    print(f"\n=== 对比结果 (seq={seq_len}) ===")
    print(f"max abs diff = {max_diff:.6f}")
    print(f"mean abs diff = {mean_diff:.6f}")
    print(f"max ref abs  = {h.abs().max().item():.6f}")
    print(f"相对误差     = {max_diff / h.abs().max().item():.2%}")

    # 预测 token 一致性
    m_pred = m.argmax(dim=-1)
    h_pred = h.argmax(dim=-1)
    same = (m_pred == h_pred).float().mean().item()
    print(f"argmax 一致率 = {same:.2%}")

    # softmax 概率对比（这才是真正影响生成质量的指标，对 logit 绝对数值不敏感）
    m_prob = m.softmax(dim=-1)
    h_prob = h.softmax(dim=-1)
    prob_diff = (m_prob - h_prob).abs()
    mean_prob_diff = prob_diff.mean().item()
    max_prob_diff = prob_diff.max().item()
    # top-5 token 重叠率
    m_top5 = m_prob.topk(5, dim=-1).indices
    h_top5 = h_prob.topk(5, dim=-1).indices
    overlap = torch.zeros_like(m_pred, dtype=torch.float32)
    for i in range(5):
        overlap += (m_top5[:, :, i].unsqueeze(-1) == h_top5).any(dim=-1).float()
    top5_overlap = (overlap > 0).float().mean().item()
    print(f"softmax 平均概率偏差 = {mean_prob_diff:.6f}")
    print(f"softmax 最大概率偏差 = {max_prob_diff:.6f}")
    print(f"top-5 覆盖率(预测集含真集至少一个) = {top5_overlap:.2%}")

    # 给出明确判断：概率分布近似一致 + 预测 token 完全一致即视为通过
    ratio = max_diff / h.abs().max().item()
    if same > 0.99 and mean_prob_diff < 0.005:
        print("\n[PASS] 转换正确（bf16 + 不同 attention 后端下数值一致）")
    elif same > 0.95 and mean_prob_diff < 0.02:
        print("\n[WARN] 基本一致，但存在少量数值偏差，建议检查")
    else:
        print("\n[FAIL] 转换有误，需要检查映射")


if __name__ == "__main__":
    main()
