#!/usr/bin/env python3
"""探针：构建 Qwen3-14B 真实配置的 mcore GPT 模型，打印 state_dict 结构。

运行方式（在 autoparallel 根目录）：
  source scripts/activate_megatron_maca.sh
  torchrun --nproc_per_node 1 generated/qwen3_finetune/probe_mcore_keys.py
"""
import sys
from pathlib import Path

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

import torch
from megatron.training.initialize import initialize_megatron
from megatron.training import get_args
from megatron.training.arguments import parse_args

sys.argv = [
    "pretrain_gpt.py",
    "--use-mcore-models",
    "--attention-backend", "flash",
    "--num-layers", "40",
    "--hidden-size", "5120",
    "--ffn-hidden-size", "17408",
    "--num-attention-heads", "40",
    "--num-query-groups", "8",
    "--group-query-attention",
    "--qk-layernorm",
    "--norm-epsilon", "1e-6",
    "--attention-softmax-in-fp32",
    "--head-dim", "128",
    "--seq-length", "2048",
    "--max-position-embeddings", "32768",
    "--position-embedding-type", "rope",
    "--normalization", "RMSNorm",
    "--swiglu",
    "--untie-embeddings-and-output-weights",
    "--disable-bias-linear",
    "--rotary-base", "1000000",
    "--tensor-model-parallel-size", "4",
    "--pipeline-model-parallel-size", "1",
    "--micro-batch-size", "1",
    "--global-batch-size", "1",
    "--bf16",
    "--no-initialization",
    "--no-load-optim",
    "--no-save-optim",
    "--no-load-rng",
    "--no-save-rng",
    "--mock-data",
    "--tokenizer-type", "NullTokenizer",
    "--vocab-size", "151936",
    "--make-vocab-size-divisible-by", "128",
    "--no-one-logger",
    "--train-iters", "0",
    "--exit-on-missing-checkpoint",
]

initialize_megatron(ignore_unknown_args=True)
args = get_args()

# 构建 mcore 模型
from pretrain_gpt import model_provider

model = model_provider(pre_process=True, post_process=True)
sd = model.state_dict()
print(f"\n=== state_dict 共 {len(sd)} 个 key（跳过 None）===")
for k, v in sd.items():
    if v is None:
        continue
    print(f"{k}: {tuple(v.shape)}")

# 顶层模块结构
print("\n=== 顶层模块 ===")
for name, mod in model.named_children():
    print(f"{name}: {type(mod).__name__}")
