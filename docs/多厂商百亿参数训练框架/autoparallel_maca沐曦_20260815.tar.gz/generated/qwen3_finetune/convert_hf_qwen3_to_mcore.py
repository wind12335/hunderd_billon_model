#!/usr/bin/env python3
"""HF Qwen3-14B safetensors → Megatron mcore checkpoint（TP 参数化）。

用法（在 autoparallel 根目录，source activate 脚本后）：
  # TP=1，只构建 + 打印，不保存（验证映射用）
  python -m torch.distributed.run --nproc_per_node 1 \
      generated/qwen3_finetune/convert_hf_qwen3_to_mcore.py --probe-only

  # TP=4，分片并保存 checkpoint 到 --save
  python -m torch.distributed.run --nproc_per_node 4 \
      generated/qwen3_finetune/convert_hf_qwen3_to_mcore.py \
      --save /path/to/ckpt_tp4

映射要点（已通过 TP1/TP4 探针确认 mcore 结构）：
  - linear_qkv  = [q;k;v] 按 query group 交错（8 组 × (5头×128 + 128 + 128)）
  - linear_fc1  = cat([gate, up], dim=0)（swiglu: silu(x0)*x1）
  - input/post_attention layernorm 融合进 linear_qkv/linear_fc1 的 layer_norm_weight
  - q/k_layernorm 为每头 head_dim 共享，直接复制
  - vocab 由 151936 pad 到 152064（尾部补零）
"""
import glob
import os
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

MODEL_DIR = "/root/workspace/model/Qwen-13B-base"
HF_VOCAB = 151936
PAD_VOCAB = 152064
NUM_Q_GROUPS = 8
NUM_HEADS = 40
HEAD_DIM = 128
# per query group: 5 q heads *128 + k(128) + v(128) = 896
GROUP_ROWS = (NUM_HEADS // NUM_Q_GROUPS) * HEAD_DIM + 2 * HEAD_DIM  # 640+128+128


def load_hf_weights(model_dir: str) -> dict:
    """加载全部 8 个 safetensors 分片。"""
    from safetensors import safe_open
    tensors = {}
    for path in sorted(glob.glob(f"{model_dir}/model-*.safetensors")):
        with safe_open(path, framework="pt") as f:
            for k in f.keys():
                tensors[k] = f.get_tensor(k)
    return tensors


def build_global_qkv(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """构造 mcore 全局 linear_qkv [7168, 5120]（按 query group 交错）。"""
    qkv = torch.zeros(
        NUM_Q_GROUPS * GROUP_ROWS, q.shape[1], dtype=q.dtype, device=q.device
    )
    q_hd = (NUM_HEADS // NUM_Q_GROUPS) * HEAD_DIM  # 640
    for g in range(NUM_Q_GROUPS):
        base = g * GROUP_ROWS
        qkv[base : base + q_hd] = q[g * q_hd : (g + 1) * q_hd]
        qkv[base + q_hd : base + q_hd + HEAD_DIM] = k[g * HEAD_DIM : (g + 1) * HEAD_DIM]
        qkv[base + q_hd + HEAD_DIM : base + GROUP_ROWS] = v[
            g * HEAD_DIM : (g + 1) * HEAD_DIM
        ]
    return qkv


def pad_vocab_rows(t: torch.Tensor) -> torch.Tensor:
    """把 [151936, hidden] pad 到 [152064, hidden]，尾部补零。"""
    padded = torch.zeros(PAD_VOCAB, t.shape[1], dtype=t.dtype, device=t.device)
    padded[:HF_VOCAB] = t
    return padded


def map_and_shard(hf: dict, model_state: dict, tp: int, rank: int) -> dict:
    """把 HF 权重映射并分片到本 rank 的 mcore state_dict。

    返回一个与 model_state 相同 key 集、可直接 load_state_dict 的 dict。
    """
    n_layers = 40
    result = {}
    for key, template in model_state.items():
        if key.endswith("_extra_state") or template is None:
            continue  # TE 内部状态不填，交给 TE 自行初始化
        result[key] = build_local_tensor(hf, key, template, tp, rank)
    return result


def build_local_tensor(hf: dict, key: str, template: torch.Tensor, tp: int, rank: int) -> torch.Tensor:
    """按 key 从 HF 权重构造本 rank 的分片张量。"""
    dtype = template.dtype
    # 词嵌入 / 输出头：vocab 行分片
    if key == "embedding.word_embeddings.weight":
        t = pad_vocab_rows(hf["model.embed_tokens.weight"]).to(dtype)
        rows = t.shape[0] // tp
        return t[rank * rows : (rank + 1) * rows].contiguous()
    if key == "output_layer.weight":
        t = pad_vocab_rows(hf["lm_head.weight"]).to(dtype)
        rows = t.shape[0] // tp
        return t[rank * rows : (rank + 1) * rows].contiguous()

    if key == "decoder.final_layernorm.weight":
        return hf["model.norm.weight"].to(dtype).contiguous()

    # 逐层权重，key 形如 decoder.layers.N.self_attention.xxx 或 decoder.layers.N.mlp.xxx
    parts = key.split(".")
    layer_idx = int(parts[2])
    group = parts[3]          # self_attention | mlp
    sub = parts[4:]            # 例如 ['linear_qkv', 'weight']

    if group == "self_attention":
        if sub == ["linear_qkv", "layer_norm_weight"]:
            return hf[f"model.layers.{layer_idx}.input_layernorm.weight"].to(dtype).contiguous()
        if sub == ["linear_qkv", "weight"]:
            q = hf[f"model.layers.{layer_idx}.self_attn.q_proj.weight"]
            k = hf[f"model.layers.{layer_idx}.self_attn.k_proj.weight"]
            v = hf[f"model.layers.{layer_idx}.self_attn.v_proj.weight"]
            g = build_global_qkv(q, k, v).to(dtype)  # [7168, 5120]
            rows = g.shape[0] // tp
            return g[rank * rows : (rank + 1) * rows].contiguous()
        if sub == ["linear_proj", "weight"]:
            t = hf[f"model.layers.{layer_idx}.self_attn.o_proj.weight"].to(dtype)  # [5120, 5120]
            cols = t.shape[1] // tp
            return t[:, rank * cols : (rank + 1) * cols].contiguous()
        if sub == ["q_layernorm", "weight"]:
            return hf[f"model.layers.{layer_idx}.self_attn.q_norm.weight"].to(dtype).contiguous()
        if sub == ["k_layernorm", "weight"]:
            return hf[f"model.layers.{layer_idx}.self_attn.k_norm.weight"].to(dtype).contiguous()
    elif group == "mlp":
        if sub == ["linear_fc1", "layer_norm_weight"]:
            return hf[f"model.layers.{layer_idx}.post_attention_layernorm.weight"].to(dtype).contiguous()
        if sub == ["linear_fc1", "weight"]:
            gate = hf[f"model.layers.{layer_idx}.mlp.gate_proj.weight"]
            up = hf[f"model.layers.{layer_idx}.mlp.up_proj.weight"]
            t = torch.cat([gate, up], dim=0).to(dtype)  # [34816, 5120]
            rows = t.shape[0] // tp
            return t[rank * rows : (rank + 1) * rows].contiguous()
        if sub == ["linear_fc2", "weight"]:
            t = hf[f"model.layers.{layer_idx}.mlp.down_proj.weight"].to(dtype)  # [5120, 17408]
            cols = t.shape[1] // tp
            return t[:, rank * cols : (rank + 1) * cols].contiguous()

    raise KeyError(f"未识别的 mcore key: {key}")


def build_megatron_args(tp: int) -> None:
    """设置 megatron 命令行参数（模型配置 = 真实 Qwen3-14B）。"""
    sys.argv = [
        "pretrain_gpt.py",
        "--use-mcore-models",
        "--attention-backend", "flash",
        "--num-layers", "40",
        "--hidden-size", "5120",
        "--ffn-hidden-size", "17408",
        "--num-attention-heads", "40",
        "--num-query-groups", "8",
        "--group-query-attention",
        "--qk-layernorm",
        "--norm-epsilon", "1e-6",
        "--attention-softmax-in-fp32",
        "--head-dim", "128",
        "--seq-length", "2048",
        "--max-position-embeddings", "32768",
        "--position-embedding-type", "rope",
        "--normalization", "RMSNorm",
        "--swiglu",
        "--untie-embeddings-and-output-weights",
        "--disable-bias-linear",
        "--rotary-base", "1000000",
        "--tensor-model-parallel-size", str(tp),
        "--pipeline-model-parallel-size", "1",
        "--micro-batch-size", "1",
        "--global-batch-size", str(tp),
        "--bf16",
        "--no-initialization",
        "--no-load-optim",
        "--no-save-optim",
        "--no-load-rng",
        "--no-save-rng",
        "--mock-data",
        "--tokenizer-type", "NullTokenizer",
        "--vocab-size", "151936",
        "--make-vocab-size-divisible-by", "128",
        "--no-one-logger",
        "--train-iters", "0",
    ]
    if "SAVE" in os.environ:
        sys.argv += ["--save", os.environ["SAVE"], "--save-interval", "0"]


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    from megatron.training import get_args

    tp = int(os.environ.get("CONVERT_TP", "1"))
    rank = int(os.environ.get("LOCAL_RANK", "0"))
    build_megatron_args(tp)
    initialize_megatron(ignore_unknown_args=True)
    args = get_args()

    from pretrain_gpt import model_provider

    model = model_provider(pre_process=True, post_process=True)

    hf = load_hf_weights(MODEL_DIR)
    model_state = model.state_dict()
    local_dict = map_and_shard(hf, model_state, tp, rank)

    # 形状校验：与模型模板逐 key 比对
    for key, t in local_dict.items():
        tmpl = model_state[key]
        if tuple(t.shape) != tuple(tmpl.shape):
            raise RuntimeError(
                f"shape mismatch {key}: got {tuple(t.shape)} expect {tuple(tmpl.shape)}"
            )
    print(f"[rank {rank}] 映射完成，{len(local_dict)} 个权重 key 形状全部匹配")

    # 载入模型
    missing, unexpected = model.load_state_dict(local_dict, strict=False)
    if missing:
        print(f"[rank {rank}] missing keys: {missing}")
    if unexpected:
        raise RuntimeError(f"[rank {rank}] unexpected keys: {unexpected}")
    print(f"[rank {rank}] load_state_dict 完成")

    if "SAVE" in os.environ:
        from megatron.training.checkpointing import save_checkpoint
        save_checkpoint(
            iteration=0,
            model=[model],
            optimizer=None,
            opt_param_scheduler=None,
            num_floating_point_operations_so_far=0.0,
        )
        print(f"[rank {rank}] checkpoint 已保存到 {args.save}")


if __name__ == "__main__":
    main()
