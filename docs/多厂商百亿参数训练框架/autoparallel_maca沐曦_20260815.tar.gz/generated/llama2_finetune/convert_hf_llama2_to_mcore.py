#!/usr/bin/env python3
"""HF llama2（含中文扩展词表变体）→ Megatron mcore checkpoint（TP 参数化，local impl）。

用法（在 autoparallel 根目录，source activate 脚本后）：
  # TP=1，只构建 + 打印，不保存（验证映射用）
  python -m torch.distributed.run --nproc_per_node 1 \
      generated/llama2_finetune/convert_hf_llama2_to_mcore.py --probe-only

  # TP=4，分片并保存 checkpoint 到 --save
  python -m torch.distributed.run --nproc_per_node 4 \
      generated/llama2_finetune/convert_hf_llama2_to_mcore.py \
      --save /path/to/ckpt_tp4

所有模型结构参数都从 config.json 动态读取（vocab/layers/heads/ffn/eps/rope），
不硬编码，适配用户下载的中文扩展词表版 llama2-13B（vocab=69104）。
"""
import glob
import json
import os
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

MODEL_DIR = "/root/workspace/model/llama-13B-base"

cfg = json.load(open(f"{MODEL_DIR}/config.json"))
HIDDEN = cfg["hidden_size"]
FFN = cfg["intermediate_size"]
N_LAYERS = cfg["num_hidden_layers"]
N_HEADS = cfg["num_attention_heads"]
N_KV_HEADS = cfg.get("num_key_value_heads", N_HEADS)
VOCAB = cfg["vocab_size"]
PAD_VOCAB = ((VOCAB + 127) // 128) * 128


def load_hf_weights(model_dir: str) -> dict:
    """加载全部权重分片（兼容 .bin 和 .safetensors 两种格式）。"""
    tensors = {}
    bins = sorted(glob.glob(f"{model_dir}/pytorch_model-*.bin"))
    sfs = sorted(glob.glob(f"{model_dir}/model-*.safetensors"))
    if sfs:
        from safetensors import safe_open

        for path in sfs:
            with safe_open(path, framework="pt") as f:
                for k in f.keys():
                    tensors[k] = f.get_tensor(k)
    elif bins:
        for path in bins:
            d = torch.load(path, map_location="cpu", weights_only=False)
            for k, v in d.items():
                tensors[k] = v
    else:
        # 单文件 model.safetensors / pytorch_model.bin
        if (Path(model_dir) / "model.safetensors").exists():
            from safetensors import safe_open

            with safe_open(f"{model_dir}/model.safetensors", framework="pt") as f:
                for k in f.keys():
                    tensors[k] = f.get_tensor(k)
        else:
            d = torch.load(f"{model_dir}/pytorch_model.bin", map_location="cpu", weights_only=False)
            tensors.update(d)
    if not tensors:
        raise RuntimeError(f"未找到权重分片: {model_dir}")
    return tensors


def build_global_qkv(q, k, v) -> torch.Tensor:
    """构造 mcore 全局 linear_qkv。

    mcore 把 mixed_qkv reshape 成 [ng, (np/ng + 2) * hn] 再按组 split 出
    q/k/v，即每个 query group 内是 q→k→v 的交错布局：
      MHA（ng=40, np/ng=1）：[q0,k0,v0, q1,k1,v1, ..., q39,k39,v39]
    不是 cat([all_q, all_k, all_v]) 的连续布局。
    """
    head_dim = q.shape[0] // N_HEADS  # hidden/num_heads
    assert q.shape[1] == k.shape[1] == v.shape[1], "q/k/v hidden 不一致"
    qkv = torch.zeros(
        N_HEADS * 3 * head_dim, q.shape[1], dtype=q.dtype, device=q.device
    )
    for i in range(N_HEADS):
        base = i * 3 * head_dim
        qkv[base : base + head_dim] = q[i * head_dim : (i + 1) * head_dim]
        qkv[base + head_dim : base + 2 * head_dim] = k[
            i * head_dim : (i + 1) * head_dim
        ]
        qkv[base + 2 * head_dim : base + 3 * head_dim] = v[
            i * head_dim : (i + 1) * head_dim
        ]
    return qkv.contiguous()


def pad_vocab_rows(t: torch.Tensor) -> torch.Tensor:
    """把 [VOCAB, hidden] pad 到 [PAD_VOCAB, hidden]，尾部补零。"""
    if t.shape[0] == PAD_VOCAB:
        return t
    padded = torch.zeros(PAD_VOCAB, t.shape[1], dtype=t.dtype, device=t.device)
    padded[: t.shape[0]] = t
    return padded


def map_and_shard(hf: dict, model_state: dict, tp: int, rank: int) -> dict:
    """把 HF 权重映射并分片到本 rank 的 mcore state_dict。"""
    result = {}
    for key, template in model_state.items():
        if template is None or key.endswith("_extra_state"):
            continue
        result[key] = build_local_tensor(hf, key, template, tp, rank)
    return result


def build_local_tensor(hf: dict, key: str, template: torch.Tensor, tp: int, rank: int) -> torch.Tensor:
    """按 key 从 HF 权重构造本 rank 的分片张量。"""
    dtype = template.dtype
    # 词嵌入 / 输出头：vocab 行分片
    if key == "embedding.word_embeddings.weight":
        t = pad_vocab_rows(hf["model.embed_tokens.weight"]).to(dtype)
        rows = t.shape[0] // tp
        return t[rank * rows : (rank + 1) * rows].contiguous()
    if key == "output_layer.weight":
        t = pad_vocab_rows(hf["lm_head.weight"]).to(dtype)
        rows = t.shape[0] // tp
        return t[rank * rows : (rank + 1) * rows].contiguous()

    if key == "decoder.final_layernorm.weight":
        return hf["model.norm.weight"].to(dtype).contiguous()

    parts = key.split(".")
    layer_idx = int(parts[2])
    group = parts[3]  # self_attention | mlp | input_layernorm | pre_mlp_layernorm
    sub = parts[4:]

    if group == "input_layernorm" and sub == ["weight"]:
        return hf[f"model.layers.{layer_idx}.input_layernorm.weight"].to(dtype).contiguous()
    # local impl 把 HF 的 post_attention_layernorm 命名为 pre_mlp_layernorm
    if group == "pre_mlp_layernorm" and sub == ["weight"]:
        return hf[f"model.layers.{layer_idx}.post_attention_layernorm.weight"].to(dtype).contiguous()

    if group == "self_attention":
        if sub == ["linear_qkv", "weight"]:
            q = hf[f"model.layers.{layer_idx}.self_attn.q_proj.weight"]
            k = hf[f"model.layers.{layer_idx}.self_attn.k_proj.weight"]
            v = hf[f"model.layers.{layer_idx}.self_attn.v_proj.weight"]
            g = build_global_qkv(q, k, v).to(dtype)  # [3*hidden, hidden]
            rows = g.shape[0] // tp
            return g[rank * rows : (rank + 1) * rows].contiguous()
        if sub == ["linear_proj", "weight"]:
            t = hf[f"model.layers.{layer_idx}.self_attn.o_proj.weight"].to(dtype)
            cols = t.shape[1] // tp
            return t[:, rank * cols : (rank + 1) * cols].contiguous()
    elif group == "mlp":
        if sub == ["linear_fc1", "weight"]:
            gate = hf[f"model.layers.{layer_idx}.mlp.gate_proj.weight"]
            up = hf[f"model.layers.{layer_idx}.mlp.up_proj.weight"]
            t = torch.cat([gate, up], dim=0).to(dtype)  # [2*ffn, hidden]
            rows = t.shape[0] // tp
            return t[rank * rows : (rank + 1) * rows].contiguous()
        if sub == ["linear_fc2", "weight"]:
            t = hf[f"model.layers.{layer_idx}.mlp.down_proj.weight"].to(dtype)
            cols = t.shape[1] // tp
            return t[:, rank * cols : (rank + 1) * cols].contiguous()

    raise KeyError(f"未识别的 mcore key: {key}")


def build_megatron_args(tp: int) -> None:
    """设置 megatron 命令行参数（从 config.json 动态读取）。"""
    sys.argv = [
        "pretrain_gpt.py",
        "--use-mcore-models",
        "--transformer-impl", "local",
        "--num-layers", str(N_LAYERS),
        "--hidden-size", str(HIDDEN),
        "--ffn-hidden-size", str(FFN),
        "--num-attention-heads", str(N_HEADS),
        "--num-query-groups", str(N_KV_HEADS),
        "--norm-epsilon", str(cfg.get("rms_norm_eps", 1e-5)),
        "--seq-length", "2048",
        "--max-position-embeddings", str(cfg.get("max_position_embeddings", 4096)),
        "--position-embedding-type", "rope",
        "--rotary-base", str(cfg.get("rotary_emb_base", cfg.get("rope_theta", 10000))),
        "--normalization", "RMSNorm",
        "--swiglu",
        "--untie-embeddings-and-output-weights",
        "--disable-bias-linear",
        "--tensor-model-parallel-size", str(tp),
        "--pipeline-model-parallel-size", "1",
        "--micro-batch-size", "1",
        "--global-batch-size", str(tp),
        "--bf16",
        "--no-initialization",
        "--no-load-optim",
        "--no-save-optim",
        "--no-load-rng",
        "--no-save-rng",
        "--mock-data",
        "--tokenizer-type", "NullTokenizer",
        "--vocab-size", str(VOCAB),
        "--make-vocab-size-divisible-by", "128",
        "--no-one-logger",
        "--train-iters", "0",
    ]
    if "SAVE" in os.environ:
        sys.argv += ["--save", os.environ["SAVE"], "--save-interval", "0"]


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    from megatron.training import get_args

    tp = int(os.environ.get("CONVERT_TP", "1"))
    rank = int(os.environ.get("LOCAL_RANK", "0"))
    build_megatron_args(tp)
    initialize_megatron(ignore_unknown_args=True)
    args = get_args()

    from pretrain_gpt import model_provider

    model = model_provider(pre_process=True, post_process=True)

    hf = load_hf_weights(MODEL_DIR)
    model_state = model.state_dict()
    local_dict = map_and_shard(hf, model_state, tp, rank)

    # 形状校验：与模型模板逐 key 比对
    for key, t in local_dict.items():
        tmpl = model_state[key]
        if tuple(t.shape) != tuple(tmpl.shape):
            raise RuntimeError(
                f"shape mismatch {key}: got {tuple(t.shape)} expect {tuple(tmpl.shape)}"
            )
    print(f"[rank {rank}] 映射完成，{len(local_dict)} 个权重 key 形状全部匹配")

    missing, unexpected = model.load_state_dict(local_dict, strict=False)
    if missing:
        print(f"[rank {rank}] missing keys: {missing}")
    if unexpected:
        raise RuntimeError(f"[rank {rank}] unexpected keys: {unexpected}")
    print(f"[rank {rank}] load_state_dict 完成")

    if "SAVE" in os.environ:
        from megatron.training.checkpointing import save_checkpoint

        save_checkpoint(
            iteration=0,
            model=[model],
            optimizer=None,
            opt_param_scheduler=None,
            num_floating_point_operations_so_far=0.0,
        )
        print(f"[rank {rank}] checkpoint 已保存到 {args.save}")


if __name__ == "__main__":
    main()
