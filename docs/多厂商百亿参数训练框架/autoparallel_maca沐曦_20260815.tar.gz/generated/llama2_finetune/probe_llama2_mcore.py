#!/usr/bin/env python3
"""探针：构建 llama2-13B 真实配置的 mcore GPT 模型（local impl），打印 state_dict 结构。

运行方式（在 autoparallel 根目录）：
  source scripts/activate_megatron_maca.sh
  python -m torch.distributed.run --nproc_per_node 1 \
      generated/llama2_finetune/probe_llama2_mcore.py
"""
import json
import os
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

MODEL_DIR = "/root/workspace/model/llama-13B-base"

from megatron.training.initialize import initialize_megatron
from megatron.training import get_args
from megatron.training.arguments import parse_args

cfg = json.load(open(f"{MODEL_DIR}/config.json"))


def build_args(tp: int, load: str | None = None) -> None:
    sys.argv = [
        "pretrain_gpt.py",
        "--use-mcore-models",
        "--transformer-impl", "local",
        "--num-layers", str(cfg["num_hidden_layers"]),
        "--hidden-size", str(cfg["hidden_size"]),
        "--ffn-hidden-size", str(cfg["intermediate_size"]),
        "--num-attention-heads", str(cfg["num_attention_heads"]),
        "--num-query-groups", str(cfg.get("num_key_value_heads", cfg["num_attention_heads"])),
        "--norm-epsilon", str(cfg.get("rms_norm_eps", 1e-5)),
        "--seq-length", "2048",
        "--max-position-embeddings", str(cfg.get("max_position_embeddings", 4096)),
        "--position-embedding-type", "rope",
        "--rotary-base", str(cfg.get("rope_theta", 10000)),
        "--normalization", "RMSNorm",
        "--swiglu",
        "--untie-embeddings-and-output-weights",
        "--disable-bias-linear",
        "--tensor-model-parallel-size", str(tp),
        "--pipeline-model-parallel-size", "1",
        "--micro-batch-size", "1",
        "--global-batch-size", str(tp),
        "--bf16",
        "--no-initialization",
        "--no-load-optim",
        "--no-save-optim",
        "--no-load-rng",
        "--no-save-rng",
        "--mock-data",
        "--tokenizer-type", "NullTokenizer",
        "--vocab-size", str(cfg["vocab_size"]),
        "--make-vocab-size-divisible-by", "128",
        "--no-one-logger",
        "--train-iters", "0",
        "--exit-on-missing-checkpoint",
    ]
    if load:
        sys.argv += ["--load", load]


build_args(tp=int(os.environ.get("PROBE_TP", "1")))
initialize_megatron(ignore_unknown_args=True)
args = get_args()

from pretrain_gpt import model_provider

model = model_provider(pre_process=True, post_process=True)
sd = model.state_dict()
print(f"\n=== llama2 mcore state_dict 共 {len(sd)} 个 key（跳过 None）===")
for k, v in sd.items():
    if v is None:
        continue
    print(f"{k}: {tuple(v.shape)}")

print("\n=== 顶层模块 ===")
for name, mod in model.named_children():
    print(f"{name}: {type(mod).__name__}")
