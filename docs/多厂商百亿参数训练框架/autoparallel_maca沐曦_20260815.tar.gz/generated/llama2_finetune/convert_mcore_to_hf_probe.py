#!/usr/bin/env python3
"""探针：TP=1 加载 mcore dist-ckpt(iter_0001449)，打印 state_dict keys/shape，验证 re-shard 能否拼回完整权重。

用法（autoparallel 根目录）：
  TORCH_COMPILE_DISABLE=1 python -m torch.distributed.run --nproc_per_node 1 \
      generated/llama2_finetune/convert_mcore_to_hf_probe.py
"""
import os
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

CKPT_DIR = "/root/workspace/finetune_ckpt/llama2_tp4/iter_0001449"

cfg = {"hidden": 5120, "ffn": 13824, "n_layers": 40, "n_heads": 40,
       "vocab": 69104, "pad_vocab": 69120}


def build_megatron_args() -> None:
    sys.argv = [
        "pretrain_gpt.py",
        "--use-mcore-models",
        "--transformer-impl", "local",
        "--num-layers", "40",
        "--hidden-size", "5120",
        "--ffn-hidden-size", "13824",
        "--num-attention-heads", "40",
        "--num-query-groups", "40",
        "--norm-epsilon", "1e-6",
        "--seq-length", "2048",
        "--max-position-embeddings", "4096",
        "--position-embedding-type", "rope",
        "--rotary-base", "10000",
        "--normalization", "RMSNorm",
        "--swiglu",
        "--untie-embeddings-and-output-weights",
        "--disable-bias-linear",
        "--tensor-model-parallel-size", "1",
        "--pipeline-model-parallel-size", "1",
        "--micro-batch-size", "1",
        "--global-batch-size", "1",
        "--bf16",
        "--no-initialization",
        "--no-load-optim",
        "--no-load-rng",
        "--no-save-optim",
        "--no-save-rng",
        "--mock-data",
        "--tokenizer-type", "NullTokenizer",
        "--vocab-size", "69104",
        "--make-vocab-size-divisible-by", "128",
        "--no-one-logger",
        "--train-iters", "0",
        "--load", CKPT_DIR,
    ]


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    build_megatron_args()
    initialize_megatron(ignore_unknown_args=True)

    from pretrain_gpt import model_provider
    model = model_provider(pre_process=True, post_process=True)

    from megatron.training.checkpointing import load_checkpoint
    it = load_checkpoint(model, None, None)
    print(f"[probe] load_checkpoint 返回 iteration = {it}")

    state = model.state_dict()
    print(f"[probe] state_dict 共 {len(state)} 个 key")
    for k, v in state.items():
        if v is None:
            print(f"  {k}: None")
        elif hasattr(v, "shape"):
            print(f"  {k}: {tuple(v.shape)}  {v.dtype}")


if __name__ == "__main__":
    main()
