#!/usr/bin/env python3
"""Megatron mcore dist-ckpt → HF llama2(中文扩展词表变体) 转换。

用 TP=1 启动加载 TP4 的训练 checkpoint(mcore 自动 re-shard 拼回完整权重),
把 mcore key 逆映射回 HF key(头级交错 qkv 拆回 q/k/v、fc1 拆回 gate/up、
vocab 去掉 128 对齐 padding),存成 HF 格式(config.json + model.safetensors)。

用法(autoparallel 根目录):
  TORCH_COMPILE_DISABLE=1 python -m torch.distributed.run --nproc_per_node 1 \
      generated/llama2_finetune/convert_mcore_to_hf.py
"""
import os
import shutil
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))

CKPT_DIR = "/root/workspace/finetune_ckpt/llama2_tp4"  # 父目录,load 通过 latest_checkpointed_iteration.txt 定位 iter_0001449
MODEL_DIR = "/root/workspace/model/llama-13B-base"
SAVE_DIR = "/root/workspace/model/llama-13B-finetuned"

import json
cfg = json.load(open(f"{MODEL_DIR}/config.json"))
HIDDEN = cfg["hidden_size"]
FFN = cfg["intermediate_size"]
N_LAYERS = cfg["num_hidden_layers"]
N_HEADS = cfg["num_attention_heads"]
VOCAB = cfg["vocab_size"]
HEAD_DIM = HIDDEN // N_HEADS


def build_megatron_args() -> None:
    sys.argv = [
        "pretrain_gpt.py",
        "--use-mcore-models",
        "--transformer-impl", "local",
        "--num-layers", str(N_LAYERS),
        "--hidden-size", str(HIDDEN),
        "--ffn-hidden-size", str(FFN),
        "--num-attention-heads", str(N_HEADS),
        "--num-query-groups", str(N_HEADS),
        "--norm-epsilon", str(cfg.get("rms_norm_eps", 1e-6)),
        "--seq-length", "2048",
        "--max-position-embeddings", str(cfg.get("max_position_embeddings", 4096)),
        "--position-embedding-type", "rope",
        "--rotary-base", str(cfg.get("rope_theta", 10000)),
        "--normalization", "RMSNorm",
        "--swiglu",
        "--untie-embeddings-and-output-weights",
        "--disable-bias-linear",
        "--tensor-model-parallel-size", "1",
        "--pipeline-model-parallel-size", "1",
        "--micro-batch-size", "1",
        "--global-batch-size", "1",
        "--bf16",
        "--no-initialization",
        "--no-load-optim",
        "--no-load-rng",
        "--no-save-optim",
        "--no-save-rng",
        "--mock-data",
        "--tokenizer-type", "NullTokenizer",
        "--vocab-size", str(VOCAB),
        "--make-vocab-size-divisible-by", "128",
        "--no-one-logger",
        "--train-iters", "0",
        "--load", CKPT_DIR,
    ]


def qkv_split(qkv: torch.Tensor) -> tuple:
    """mcore 头级交错 linear_qkv [3H, H] → q/k/v 三个 [H, H]。

    布局 [q0,k0,v0, q1,k1,v1, ..., q39,k39,v39],每组 head_dim 行。
    reshape(N_HEADS, 3, HEAD_DIM, -1) 后第二维即 q/k/v。
    """
    r = qkv.reshape(N_HEADS, 3, HEAD_DIM, -1)
    q = r[:, 0].reshape(-1, qkv.shape[1]).contiguous()
    k = r[:, 1].reshape(-1, qkv.shape[1]).contiguous()
    v = r[:, 2].reshape(-1, qkv.shape[1]).contiguous()
    return q, k, v


def mcore_to_hf(state: dict) -> dict:
    """mcore state_dict → HF state_dict。"""
    hf = {}
    hf["model.embed_tokens.weight"] = state["embedding.word_embeddings.weight"][:VOCAB]
    hf["lm_head.weight"] = state["output_layer.weight"][:VOCAB]
    hf["model.norm.weight"] = state["decoder.final_layernorm.weight"]

    for i in range(N_LAYERS):
        pre = f"decoder.layers.{i}"
        lay = f"model.layers.{i}"
        hf[f"{lay}.input_layernorm.weight"] = state[f"{pre}.input_layernorm.weight"]
        hf[f"{lay}.post_attention_layernorm.weight"] = state[f"{pre}.pre_mlp_layernorm.weight"]

        q, k, v = qkv_split(state[f"{pre}.self_attention.linear_qkv.weight"])
        hf[f"{lay}.self_attn.q_proj.weight"] = q
        hf[f"{lay}.self_attn.k_proj.weight"] = k
        hf[f"{lay}.self_attn.v_proj.weight"] = v
        hf[f"{lay}.self_attn.o_proj.weight"] = state[f"{pre}.self_attention.linear_proj.weight"]

        fc1 = state[f"{pre}.mlp.linear_fc1.weight"]
        ffn = fc1.shape[0] // 2
        hf[f"{lay}.mlp.gate_proj.weight"] = fc1[:ffn].contiguous()
        hf[f"{lay}.mlp.up_proj.weight"] = fc1[ffn:].contiguous()
        hf[f"{lay}.mlp.down_proj.weight"] = state[f"{pre}.mlp.linear_fc2.weight"]
    return hf


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    build_megatron_args()
    initialize_megatron(ignore_unknown_args=True)

    from pretrain_gpt import model_provider
    model = model_provider(pre_process=True, post_process=True)

    from megatron.training.checkpointing import load_checkpoint
    it = load_checkpoint([model], None, None)
    print(f"[convert] 已加载 checkpoint iteration = {it}")

    state = model.state_dict()
    hf = mcore_to_hf(state)
    print(f"[convert] 逆映射完成: {len(hf)} 个 HF key")

    # 形状 sanity
    for k, v in hf.items():
        if "norm" in k:
            assert v.dim() == 1
        else:
            assert v.dim() == 2, (k, v.shape)
    print("[convert] 形状检查通过")

    os.makedirs(SAVE_DIR, exist_ok=True)
    shutil.copy(f"{MODEL_DIR}/config.json", f"{SAVE_DIR}/config.json")

    from safetensors.torch import save_file
    save_file(hf, f"{SAVE_DIR}/model.safetensors")
    print(f"[convert] 已保存到 {SAVE_DIR} (model.safetensors, "
          f"{sum(v.numel()*v.element_size() for v in hf.values())/1e9:.1f} GB)")
    print("[convert] 完成")


if __name__ == "__main__":
    main()
