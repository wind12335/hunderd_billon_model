#!/usr/bin/env python3
"""Infinity-Instruct-7M-Core parquet → llama2 chat 格式 jsonl。

llama2 指令格式（无 system）：
  <s>[INST] {user} [/INST] {assistant} </s>
多轮对话按顺序拼接；若有 system 消息，加到第一轮 INST 前。
"""
import glob
import json
import sys
import time

import pyarrow.parquet as pq

DATA_DIR = "/root/workspace/datasets/Infinity-Instruct-7M-Core/7M_core"
OUT = "/root/workspace/datasets/Infinity-Instruct-7M-Core/llama2_chat.jsonl"


def fmt_conv(msgs) -> str:
    sys_prompt = None
    turns = []
    for m in msgs:
        role = m.get("from", "")
        text = m.get("value", "")
        if role == "system":
            sys_prompt = text
        elif role in ("human", "user"):
            turns.append(("user", text))
        elif role in ("gpt", "assistant"):
            turns.append(("assistant", text))

    parts = []
    i = 0
    while i < len(turns):
        if turns[i][0] != "user":
            i += 1
            continue
        user_text = turns[i][1]
        if sys_prompt is not None and i == 0:
            user_text = f"<<SYS>>\n{sys_prompt}\n<</SYS>>\n\n{user_text}"
        parts.append(f"<s>[INST] {user_text} [/INST]")
        # 收集该 user 之后连续的 assistant 回复
        j = i + 1
        replies = []
        while j < len(turns) and turns[j][0] == "assistant":
            replies.append(turns[j][1])
            j += 1
        if replies:
            parts.append(" ".join(replies))
        parts.append("</s>")
        i = j
    return "".join(parts)


def main() -> None:
    files = sorted(glob.glob(f"{DATA_DIR}/*.parquet"))
    if not files:
        sys.exit(f"未找到 parquet: {DATA_DIR}/*.parquet")
    t0 = time.time()
    n = 0
    empty = 0
    with open(OUT, "w", encoding="utf-8") as f:
        for fp in files:
            table = pq.read_table(fp, columns=["conversations"])
            arr = table.column("conversations").to_pylist()
            for conv in arr:
                text = fmt_conv(conv)
                if not text.strip():
                    empty += 1
                    continue
                f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
                n += 1
            print(
                f"  {fp} 完成, 累计 {n} 行, 用时 {time.time()-t0:.1f}s",
                flush=True,
            )
    print(f"全部完成: {n} 行 -> {OUT}（空样本 {empty} 条跳过）")


if __name__ == "__main__":
    main()
