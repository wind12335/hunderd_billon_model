"""声明式 autoparallel 入口：llama2-13B 微调。

run_mode="LOWER" 只生成 launch 脚本，不执行训练。
"""
from __future__ import annotations

from autoparallel import Config
from autoparallel import parallelize


config = Config(
    model_path='/root/workspace/model/llama-13B-base',
    search_target_devices=8,
    runtime_test_devices=8,
    memory_target_gb=None,
    prefer='MEMORY',
    search_strategy='BLOCK_LEVEL_FAST',
    search_policy='BALANCED',
    data_path='/root/workspace/datasets/Infinity-Instruct-7M-Core/megatron/llama2',
    tokenizer_path='/root/workspace/model/llama-13B-base/tokenizer.model',
    output_dir='/root/workspace/finetune_ckpt/llama2_generated',
    run_mode="LOWER",
    train_iters=2,
    sequence_length=2048,
)
config.parallel_mode = "MODEL_PARALLEL"


@parallelize(config)
def train() -> None:
    """只保留训练意图，不手写 PP/TP shard 和通信细节。"""
    pass


if __name__ == "__main__":
    train()
