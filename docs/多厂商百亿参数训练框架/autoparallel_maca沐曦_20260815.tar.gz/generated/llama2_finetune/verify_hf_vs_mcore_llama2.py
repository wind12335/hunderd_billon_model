#!/usr/bin/env python3
"""验证 HF llama2 与转换后的 mcore 模型输出 logits 一致性。

用法（autoparallel 根目录）：
  python -m torch.distributed.run --nproc_per_node 1 \
      generated/llama2_finetune/verify_hf_vs_mcore_llama2.py
"""
import sys
from pathlib import Path

import torch

ROOT = Path("/root/workspace/software/autoparallel")
sys.path.insert(0, str(ROOT / "Megatron-LM"))
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "generated/llama2_finetune"))

MODEL_DIR = "/root/workspace/model/llama-13B-base"

import convert_hf_llama2_to_mcore as conv


def main() -> None:
    from megatron.training.initialize import initialize_megatron
    from megatron.training import get_args
    from megatron.training.utils import get_ltor_masks_and_position_ids

    conv.build_megatron_args(tp=1)
    initialize_megatron(ignore_unknown_args=True)
    args = get_args()

    from pretrain_gpt import model_provider

    model = model_provider(pre_process=True, post_process=True).cuda().to(torch.bfloat16)
    model.eval()

    hf = conv.load_hf_weights(MODEL_DIR)
    model_state = model.state_dict()
    local_dict = conv.map_and_shard(hf, model_state, tp=1, rank=0)
    model.load_state_dict(local_dict, strict=False)
    print("[mcore] 权重载入完成")

    torch.manual_seed(0)
    seq_len = 32
    input_ids = torch.randint(0, 1000, (1, seq_len)).cuda()

    with torch.no_grad():
        attention_mask, position_ids, _ = get_ltor_masks_and_position_ids(
            input_ids,
            args.vocab_size,
            args.reset_position_ids,
            args.reset_attention_mask,
            args.eod_mask_loss,
        )
        mcore_logits = model(
            input_ids,
            position_ids,
            attention_mask,
            runtime_gather_output=True,
        ).float()

    print("[mcore] 前向完成, logits shape:", tuple(mcore_logits.shape))

    from transformers import AutoModelForCausalLM

    print("[hf] 加载 HF 模型到 CPU ...")
    hf_model = AutoModelForCausalLM.from_pretrained(
        MODEL_DIR,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=False,
    )
    hf_model.eval()
    with torch.no_grad():
        hf_logits = hf_model(input_ids.cpu()).logits.float()

    print("[hf] 前向完成, logits shape:", tuple(hf_logits.shape))

    vocab = conv.VOCAB
    m = mcore_logits[:, :, :vocab].cpu()
    h = hf_logits
    assert m.shape == h.shape, f"shape mismatch {m.shape} vs {h.shape}"

    print(f"mcore logits: mean={m.mean():.4f} std={m.std():.4f} min={m.min():.4f} max={m.max():.4f}")
    print(f"hf    logits: mean={h.mean():.4f} std={h.std():.4f} min={h.min():.4f} max={h.max():.4f}")
    m_top = m.softmax(dim=-1).max(dim=-1).values.mean().item()
    h_top = h.softmax(dim=-1).max(dim=-1).values.mean().item()
    print(f"top1 概率  mcore={m_top:.6f}  hf={h_top:.6f}  (接近均匀 {1/vocab:.6f} 说明无区分度)")

    diff = (m - h).abs()
    max_diff = diff.max().item()
    mean_diff = diff.mean().item()
    print(f"\n=== 对比结果 (seq={seq_len}) ===")
    print(f"max abs diff = {max_diff:.6f}")
    print(f"mean abs diff = {mean_diff:.6f}")
    print(f"max ref abs  = {h.abs().max().item():.6f}")
    print(f"相对误差     = {max_diff / h.abs().max().item():.2%}")

    m_pred = m.argmax(dim=-1)
    h_pred = h.argmax(dim=-1)
    same = (m_pred == h_pred).float().mean().item()
    print(f"argmax 一致率 = {same:.2%}")

    m_prob = m.softmax(dim=-1)
    h_prob = h.softmax(dim=-1)
    mean_prob_diff = (m_prob - h_prob).abs().mean().item()
    print(f"softmax 平均概率偏差 = {mean_prob_diff:.6f}")

    if same > 0.99 and mean_prob_diff < 0.005:
        print("\n[PASS] 转换正确（bf16 精度范围内一致）")
    elif same > 0.95 and mean_prob_diff < 0.02:
        print("\n[WARN] 基本一致，但存在少量数值偏差，建议检查")
    else:
        print("\n[FAIL] 转换有误，需要检查映射")


if __name__ == "__main__":
    main()
