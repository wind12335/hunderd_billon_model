#!/usr/bin/env python3
"""海光版 Megatron 环境 bootstrap。

这个模块负责把当前仓库里的 `Megatron-LM` 源码作为上游接口层挂进
`sys.path`，随后再导入 `dcu_megatron` 以应用海光补丁。

设计目标：
1. 不改动官方源码目录。
2. 运行入口统一走海光补丁链路。
3. 在当前仓库任意位置执行时都能得到一致结果。
"""

from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path


_BOOTSTRAPPED = False


def _repo_root() -> Path:
    """返回当前仓库根目录。"""
    return Path(__file__).resolve().parent.parent


def _upstream_root() -> Path:
    """返回本地 Megatron-LM 源码目录。"""
    return _repo_root() / "Megatron-LM"


def _prepend_sys_path(path: Path) -> None:
    """把路径放到 sys.path 前部，同时避免重复项。"""
    path_str = str(path)
    sys.path[:] = [entry for entry in sys.path if entry != path_str]
    sys.path.insert(0, path_str)


def bootstrap(verbose: bool = False) -> dict[str, str]:
    """初始化海光 Megatron 运行环境。

    返回值用于调试和自检，包含仓库根目录、上游源码目录和补丁模块信息。
    """
    global _BOOTSTRAPPED

    repo_root = _repo_root()
    upstream_root = _upstream_root()

    if not upstream_root.is_dir():
        raise FileNotFoundError(
            f"未找到上游 Megatron-LM 源码目录: {upstream_root}"
        )

    # 先把本地 Megatron-LM 源码放到 import 链路前面，保证
    # `megatron.training` 等官方接口存在，随后再由 dcu_megatron 打补丁。
    _prepend_sys_path(upstream_root)

    # 记录环境，便于脚本和排障时直接查看。
    os.environ.setdefault("MEGATRON_PROJECT_ROOT", str(repo_root))
    os.environ.setdefault("MEGATRON_UPSTREAM_ROOT", str(upstream_root))
    os.environ.setdefault("MEGATRON_HYGON_ENABLED", "1")

    # 先加载上游训练接口，再导入海光补丁层。
    importlib.import_module("megatron.training.arguments")

    if not _BOOTSTRAPPED:
        importlib.import_module("dcu_megatron")
        _BOOTSTRAPPED = True

    patched_module = importlib.import_module("megatron.training.arguments")
    patched_parse_args = getattr(patched_module, "parse_args", None)
    patched_module_name = getattr(patched_parse_args, "__module__", "")

    if not patched_module_name.startswith("dcu_megatron."):
        raise RuntimeError(
            "海光补丁未生效: megatron.training.arguments.parse_args "
            f"当前来自 {patched_module_name or unknown}"
        )

    info = {
        "repo_root": str(repo_root),
        "upstream_root": str(upstream_root),
        "patched_parse_args_module": patched_module_name,
    }

    if verbose:
        print("[megatron-hygon-bootstrap] repo_root =", info["repo_root"])
        print("[megatron-hygon-bootstrap] upstream_root =", info["upstream_root"])
        print(
            "[megatron-hygon-bootstrap] patched_parse_args_module =",
            info["patched_parse_args_module"],
        )

    return info


if __name__ == "__main__":
    bootstrap(verbose=True)
