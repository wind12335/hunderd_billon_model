#!/usr/bin/env bash

# 海光版 Megatron 环境激活脚本。
# 用法：
#   source scripts/activate_megatron_hygon.sh

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  echo "请使用 source 激活环境: source scripts/activate_megatron_hygon.sh"
  exit 1
fi

_megatron_hygon_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_megatron_hygon_root="$(cd "${_megatron_hygon_script_dir}/.." && pwd)"
_megatron_hygon_upstream="${_megatron_hygon_root}/Megatron-LM"
_megatron_hygon_tools="${_megatron_hygon_root}/tools"

if [[ ! -d "${_megatron_hygon_upstream}" ]]; then
  echo "未找到上游 Megatron-LM 源码目录: ${_megatron_hygon_upstream}"
  return 1
fi

if [[ -d "/opt/dtk" ]]; then
  export DTK_HOME="/opt/dtk"
  export ROCM_HOME="${ROCM_HOME:-/opt/dtk}"
  export HIP_PATH="${HIP_PATH:-/opt/dtk}"
  export PATH="/opt/dtk/bin:${PATH}"
  export LD_LIBRARY_PATH="/opt/dtk/lib:/opt/dtk/lib64:${LD_LIBRARY_PATH:-}"
fi

export MEGATRON_PROJECT_ROOT="${_megatron_hygon_root}"
export MEGATRON_UPSTREAM_ROOT="${_megatron_hygon_upstream}"
export MEGATRON_HYGON_ENABLED="1"
export PYTHONPATH="${_megatron_hygon_tools}:${_megatron_hygon_upstream}:${PYTHONPATH:-}"

echo "[megatron-hygon] MEGATRON_PROJECT_ROOT=${MEGATRON_PROJECT_ROOT}"
echo "[megatron-hygon] MEGATRON_UPSTREAM_ROOT=${MEGATRON_UPSTREAM_ROOT}"
echo "[megatron-hygon] PYTHONPATH 已追加 tools 和 Megatron-LM"
echo "[megatron-hygon] 如需自检，请执行: python3 tools/check_megatron_hygon_env.py"
